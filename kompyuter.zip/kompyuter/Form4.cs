﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace kompyuter
{
    public partial class Form4 : Form
    {
        OleDbConnection con;
        public Form4()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/Asus/Desktop/kompyuter.mdb");
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Xizmat_turi";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Xizmat_turi (Nomi, Narxi) VALUES (@Nomi, @Narxi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@Narxi", textBox2.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Xizmat_turi SET Nomi=@Nomi, Narxi=@Narxi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@Narxi", textBox2.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Xizmat_turi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow a = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = a.Cells["Nomi"].Value.ToString();
                textBox2.Text = a.Cells["Narxi"].Value.ToString();
            }
        }
    }
}
