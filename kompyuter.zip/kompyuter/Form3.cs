﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace kompyuter
{
    public partial class Form3 : Form
    {
        OleDbConnection con;
        public Form3()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/Asus/Desktop/kompyuter.mdb");
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Texniklar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Texniklar (Ism, Mutaxassislik, Telefon) VALUES (@Ism, @Mutaxassislik, @Telefon)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism", textBox1.Text);
            cmd.Parameters.AddWithValue("@Mutaxassislik", textBox2.Text);
            cmd.Parameters.AddWithValue("@Telefon", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Texniklar SET Ism=@Ism, Mutaxassislik=@Mutaxassislik, Telefon=@Telefon WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism", textBox1.Text);
            cmd.Parameters.AddWithValue("@Mutaxassislik", textBox2.Text);
            cmd.Parameters.AddWithValue("@Telefon", textBox3.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Texniklar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow a = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = a.Cells[1].Value.ToString();
                textBox2.Text = a.Cells[2].Value.ToString();
                textBox3.Text = a.Cells[3].Value.ToString();
            }
        }
    }
}
