﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace kompyuter
{
    public partial class Form1 : Form
    {
        OleDbConnection con;

        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/Asus/Desktop/kompyuter.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            display();
            Mijoz();
            texnik();
            xizmat();
            panel1.Visible = false;
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Buyurtmalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        void Mijoz()
        {
            con.Open();
            string query = "SELECT * FROM Mijozlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Ism";
            comboBox1.ValueMember = "Ism";
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        void texnik()
        {
            con.Open();
            string query = "SELECT * FROM Texniklar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = "Ism";
            comboBox2.ValueMember = "Ism";
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        void xizmat()
        {
            con.Open();
            string query = "SELECT * FROM Xizmat_turi";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox3.DataSource = dt;
            comboBox3.DisplayMember = "Nomi";
            comboBox3.ValueMember = "Nomi";
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        void narx(string xizmatNomi)
        {
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            string query = "SELECT Narxi FROM Xizmat_turi WHERE Nomi = @Nomi";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Nomi", xizmatNomi);
            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                textBox2.Text = result.ToString();
            }
            cmd.Dispose();
            con.Close();
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedValue != null && comboBox3.SelectedValue.ToString() != "")
            {
                string xizmatNomi = comboBox3.SelectedValue.ToString();
                narx(xizmatNomi);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            string query = "INSERT INTO Buyurtmalar (Mijoz, Texnik, Buyurtma_sanasi, Holati, Xizmat_turi) VALUES (@Mijoz, @Texnik, @Buyurtma_sanasi, @Holati, @Xizmat_turi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Mijoz", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Texnik", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Buyurtma_sanasi", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@Holati", textBox1.Text);
            cmd.Parameters.AddWithValue("@Xizmat_turi", comboBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Visible = !panel1.Visible;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Buyurtmalar SET Mijoz=@Mijoz, Texnik=@Texnik, Buyurtma_sanasi=@Buyurtma_sanasi, Holati=@Holati, Xizmat_turi=@Xizmat_turi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Mijoz", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Texnik", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Buyurtma_sanasi", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@Holati", textBox1.Text);
            cmd.Parameters.AddWithValue("@Xizmat_turi", comboBox3.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Buyurtmalar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow a = dataGridView1.Rows[e.RowIndex];
                comboBox1.Text = a.Cells[1].Value.ToString();
                comboBox2.Text = a.Cells[2].Value.ToString();
                textBox1.Text = a.Cells[4].Value.ToString();
                comboBox3.Text = a.Cells[5].Value.ToString();
                
            }
        }
    }
}


