﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Maktab
{
    public partial class Form1 : Form
    {
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Maktab.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            display1();
            display2();
            display3();
            display4();
            display6();
            sinfcombo4();
            sinfcombo1();
            fancombo2();
            studentcombo6();
            fancombo7();
            panel1.Visible = false;
            comboBox5.Items.Add("Algebra");
            comboBox5.Items.Add("Fizika");
            comboBox5.Items.Add("Geografiya");
            comboBox5.Items.Add("Tarix");
            comboBox5.Items.Add("Geometriya");
            comboBox5.Items.Add("Biologiya");
            comboBox5.Items.Add("Kimyo");
            comboBox5.Items.Add("Ona_tili");
            comboBox3.Items.Add("Dushanba");
            comboBox3.Items.Add("Seshanba");
            comboBox3.Items.Add("Chorshanba");
            comboBox3.Items.Add("Payshanba");
            comboBox3.Items.Add("Juma");
            comboBox3.Items.Add("Shanba");
        }
        void display1()
        {
            con.Open();
            string query = "SELECT * FROM Dars_jadvali";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        void display2()
        {
            con.Open();
            string query = "SELECT * FROM Students";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
            con.Close();
        }
        void display3()
        {
            con.Open();
            string query = "SELECT * FROM Teachers";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView3.DataSource = dt;
            con.Close();
        }
        void display4()
        {
            con.Open();
            string query = "SELECT * FROM Sinf";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView4.DataSource = dt;
            con.Close();
        }
        void display6()
        {
            con.Open();
            string query = "SELECT * FROM Baho";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView6.DataSource = dt;
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible =! panel1.Visible;
        }        
        //Sinf
        private void button16_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Sinf (Sinf_nomi, Sinf_rahbari) VALUES (@Sinf_nomi, @Sinf_rahbari)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Sinf_nomi", textBox10.Text);
            cmd.Parameters.AddWithValue("@Sinf_rahbari", textBox11.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        private void button17_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView4.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView4.Rows[index].Cells[0].Value);
            string query = "UPDATE Sinf SET Sinf_nomi=@Sinf_nomi, Sinf_rahbari=@Sinf_rahbari WHERE SinfID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Sinf_nomi", textBox10.Text);
            cmd.Parameters.AddWithValue("@Sinf_rahbari", textBox11.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        private void button18_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView4.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView4.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Sinf WHERE SinfID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        //O'quvchi
        void sinfcombo4()
        {
            con.Open();
            string query = "SELECT * FROM Sinf";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox4.DataSource = dt;
            comboBox4.ValueMember = "Sinf_nomi";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Students (Ism_Familiya, Tugilgan_sanasi, Sinfi, Yashash_manzili, Telefon_raqami, Ota_onasining_ismi, Ota_onasining_tel_raqami) VALUES (@Ism_Familiya, @Tugilgan_sanasi, @Sinfi, @Yashash_manzili, @Telefon_raqami, @Ota_onasining_ismi, @Ota_onasining_tel_raqami)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism_Familiya", textBox3.Text);
            cmd.Parameters.AddWithValue("@Tugilgan_sanasi", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@Sinfi", comboBox4.Text);
            cmd.Parameters.AddWithValue("@Yashash_manzili", textBox4.Text);
            cmd.Parameters.AddWithValue("@Telefon_raqami", textBox5.Text);
            cmd.Parameters.AddWithValue("@Ota_onasining_ismi", textBox6.Text);
            cmd.Parameters.AddWithValue("@Ota_onasining_tel_raqami", textBox7.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        private void button11_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "UPDATE Students SET Ism_Familiya=@Ism_Familiya, Tugilgan_sanasi=@Tugilgan_sanasi, Sinfi=@Sinfi, Yashash_manzili=@Yashash_manzili, Telefon_raqami=@Telefon_raqami, Ota_onasining_ismi=@Ota_onasining_ismi, Ota_onasining_tel_raqami=@Ota_onasining_tel_raqami WHERE StudentID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism_Familiya", textBox3.Text);
            cmd.Parameters.AddWithValue("@Tugilgan_sanasi", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@Sinfi", comboBox4.Text);
            cmd.Parameters.AddWithValue("@Yashash_manzili", textBox4.Text);
            cmd.Parameters.AddWithValue("@Telefon_raqami", textBox5.Text);
            cmd.Parameters.AddWithValue("@Ota_onasining_ismi", textBox6.Text);
            cmd.Parameters.AddWithValue("@Ota_onasining_tel_raqami", textBox7.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        private void button12_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Students WHERE StudentID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        //O'qituvchi        
        private void button13_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Teachers (Ism_Familiya, Fan, Tel_raqami, Ishga_kirgan_sanasi) VALUES (@Ism_Familiya, @Fan, @Tel_raqami, @Ishga_kirgan_sanasi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism_Familiya", textBox8.Text);
            cmd.Parameters.AddWithValue("@Fan", comboBox5.SelectedItem?.ToString());
            cmd.Parameters.AddWithValue("@Tel_raqami", textBox9.Text);
            cmd.Parameters.AddWithValue("@Ishga_kirgan_sanasi", dateTimePicker2.Value);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void button14_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "UPDATE Teachers SET Ism_Familiya=@Ism_Familiya, Fan=@Fan, Tel_raqami=@Tel_raqami, Ishga_kirgan_sanasi=@Ishga_kirgan_sanasi WHERE TeacherID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism_Familiya", textBox8.Text);
            cmd.Parameters.AddWithValue("@Fan", comboBox5.SelectedItem?.ToString());
            cmd.Parameters.AddWithValue("@Tel_raqami", textBox9.Text);
            cmd.Parameters.AddWithValue("@Ishga_kirgan_sanasi", dateTimePicker2.Value);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void button15_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Teachers WHERE TeacherID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        //Dars jadvali
        void sinfcombo1()
        {
            con.Open();
            string query = "SELECT * FROM Sinf";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "Sinf_nomi";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void fancombo2()
        {
            con.Open();
            string query = "SELECT * FROM Teachers";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox2.DataSource = dt;
            comboBox2.ValueMember = "Fan";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Dars_jadvali (Sinf, Fan, Hafta_kuni, Dars_boshlanish_vaqti, Dars_tugash_vaqti) VALUES (@Sinf, @Fan, @Hafta_kuni, @Dars_boshlanish_vaqti, @Dars_tugash_vaqti)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Sinf", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Fan", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Hafta_kuni", comboBox3.SelectedItem?.ToString());
            cmd.Parameters.AddWithValue("@Dars_boshlanish_vaqti", textBox1.Text);
            cmd.Parameters.AddWithValue("@Dars_tugash_vaqti", textBox2.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Dars_jadvali SET Sinf=@Sinf, Fan=@Fan, Hafta_kuni=@Hafta_kuni, Dars_boshlanish_vaqti=@Dars_boshlanish_vaqti, Dars_tugash_vaqti=@Dars_tugash_vaqti WHERE TimetableID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Sinf", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Fan", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Hafta_kuni", comboBox3.SelectedItem?.ToString());
            cmd.Parameters.AddWithValue("@Dars_boshlanish_vaqti", textBox1.Text);
            cmd.Parameters.AddWithValue("@Dars_tugash_vaqti", textBox2.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Dars_jadvali WHERE TimetableID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        //Baho
        void studentcombo6()
        {
            con.Open();
            string query = "SELECT * FROM Students";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox6.DataSource = dt;
            comboBox6.ValueMember = "Ism_Familiya";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void fancombo7()
        {
            con.Open();
            string query = "SELECT * FROM Teachers";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox7.DataSource = dt;
            comboBox7.ValueMember = "Fan";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void button19_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Baho (Student, Fan, Baho, Baho_sanasi) VALUES (@Student, @Fan, @Baho, @Baho_sanasi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Student", comboBox6.Text);
            cmd.Parameters.AddWithValue("@Fan", comboBox7.Text);
            cmd.Parameters.AddWithValue("@Baho", textBox14.Text);
            cmd.Parameters.AddWithValue("@Baho_sanasi", dateTimePicker3.Value);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display6();
        }
        private void button20_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Baho SET Student=@Student, Fan=@Fan, Baho=@Baho, Baho_sanasi=@Baho_sanasi WHERE GradeID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Student", comboBox6.Text);
            cmd.Parameters.AddWithValue("@Fan", comboBox7.Text);
            cmd.Parameters.AddWithValue("@Baho", textBox14.Text);
            cmd.Parameters.AddWithValue("@Baho_sanasi", dateTimePicker3.Value);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display6();
        }
        private void button21_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Baho WHERE GradeID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display6();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage6;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void button23_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }
    }
}
