﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Institut.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }
        private void button9_Click(object sender, EventArgs e)
        {
            panel1.Visible = !panel1.Visible;
        }
        private void button1_Click(object sender, EventArgs e)
        {
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            form2.GoToFakultetPage();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            form2.GoToTalabalarPage();
            this.Hide();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            form2.GoToUqituvchilarPage();
            this.Hide();
        } 
        private void button5_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            form2.GoToFanlarPage();
            this.Hide();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            form2.GoToTalabani_baholashPage();
            this.Hide();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            form2.GoToGPA_ballPage();
            this.Hide();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
