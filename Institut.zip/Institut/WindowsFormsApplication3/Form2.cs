﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication3
{
    public partial class Form2 : Form
    {
        OleDbConnection con;
        public Form2()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Institut.mdb");
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            display1();
            display2();
            display3();
            display4();
            display5();
            fan_nomi();
            LoadFakultetComboBox();
            TalabalarFakultet();
            FanFakultet();
            Tal_baho_Fakultet();
            panel1.Visible = true;
            panel2.Visible = false;
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
            dataGridView2.CellClick += new DataGridViewCellEventHandler(dataGridView2_CellClick);
            dataGridView3.CellClick += new DataGridViewCellEventHandler(dataGridView3_CellClick);
            dataGridView4.CellClick += new DataGridViewCellEventHandler(dataGridView4_CellClick);
            dataGridView5.CellClick += new DataGridViewCellEventHandler(dataGridView5_CellClick);
        }
        void display1()
        {
            con.Open();
            string query = "SELECT * FROM Fakultet";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display2()
        {
            con.Open();
            string query = "SELECT * FROM Talabalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display3()
        {
            con.Open();
            string query = "SELECT * FROM Fanlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView3.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display4()
        {
            con.Open();
            string query = "SELECT * FROM Uqituvchilar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView4.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display5()
        {
            con.Open();
            string query = "SELECT * FROM Talabani_baholash";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView5.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }        
        void fan_nomi()
        {
            con.Open();
            string query = "SELECT Fan_nomi FROM Fanlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox7.DataSource = dt;
            comboBox7.DisplayMember = "Fan_nomi";
            comboBox7.ValueMember = "Fan_nomi";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }        
        private void LoadGuruhComboBox(string fakultet)
        {
            
            {
                try
                {
                    
                    string query = "SELECT Guruh FROM Fakultet WHERE Fakultet = @fakultet";
                    OleDbCommand command = new OleDbCommand(query, con);
                    command.Parameters.AddWithValue("@fakultet", fakultet);
                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    comboBox2.DataSource = table;
                    comboBox2.DisplayMember = "Guruh";
                    comboBox2.ValueMember = "Guruh";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xatolik: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        private void LoadFakultetComboBox()
        {
            con.Open();
            string query = "SELECT DISTINCT Fakultet FROM Fakultet";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox1.DataSource = table;
            comboBox1.DisplayMember = "Fakultet";
            comboBox1.ValueMember = "Fakultet";
            con.Close();
        }
        public void GoToTalabalarPage()
        {
            TabControl1.SelectedTab = TabControl1.TabPages["Talabalar"];
        }
        public void GoToFakultetPage()
        {
            TabControl1.SelectedTab = TabControl1.TabPages["Fakultet"];
        }
        public void GoToFanlarPage()
        {
            TabControl1.SelectedTab = TabControl1.TabPages["Fanlar"];
        }
        public void GoToUqituvchilarPage()
        {
            TabControl1.SelectedTab = TabControl1.TabPages["Uqituvchilar"];
        }
        public void GoToTalabani_baholashPage()
        {
            TabControl1.SelectedTab = TabControl1.TabPages["Talabani_baholash"];
        }
        public void GoToGPA_ballPage()
        {
            TabControl1.SelectedTab = TabControl1.TabPages["GPA_ball"];
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Fakultet (Fakultet, Guruh, Uquvchilar_soni) VALUES (@Fakultet, @Guruh, @Uquvchilar_soni)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Guruh", textBox2.Text);
            cmd.Parameters.AddWithValue("@Uquvchilar_soni", textBox1.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedFakultet = comboBox1.SelectedValue.ToString();
            LoadGuruhComboBox(selectedFakultet);
        }
        private void button10_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        public void panel()
        {
            panel1.Visible = !panel1.Visible;
            panel2.Visible = !panel2.Visible;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Fakultet SET Fakultet=@Fakultet, Guruh=@Guruh, Uquvchilar_soni=@Uquvchilar_soni WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Guruh", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Uquvchilar_soni", textBox1.Text);
            cmd.Parameters.AddWithValue("id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Fakultet WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridView1.CurrentRow.Index;
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            textBox1.Text = row.Cells["Uquvchilar_soni"].Value.ToString();
            textBox2.Text = row.Cells["Guruh"].Value.ToString();
            comboBox2.Text = row.Cells["Guruh"].Value.ToString();
            comboBox1.Text = row.Cells["Fakultet"].Value.ToString();
        }
        //Talabalar   Talabalar   Talabalar
        private void TalabaGuruh(string fakultet)
        {
            string query = "SELECT Guruh FROM Fakultet WHERE Fakultet = @fakultet";
            OleDbCommand command = new OleDbCommand(query, con);
            command.Parameters.AddWithValue("@fakultet", fakultet);
            OleDbDataAdapter adapter = new OleDbDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox4.DataSource = table;
            comboBox4.DisplayMember = "Guruh";
            comboBox4.ValueMember = "Guruh";
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedValue != null)
            {
                string TalabaFakultet = comboBox3.SelectedValue.ToString();
                TalabaGuruh(TalabaFakultet);
            }
        }
        private void TalabalarFakultet()
        {
            con.Open();
            string query = "SELECT DISTINCT Fakultet FROM Fakultet";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox3.DataSource = table;
            comboBox3.DisplayMember = "Fakultet";
            comboBox3.ValueMember = "Fakultet";
            con.Close();
        }
        private void button11_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Talabalar (Fakultet, Guruh, FIO, Pasport_malumoti, Otasi, Onasi, Tel_raqami, Nechanchi_kurs) VALUES (@Fakultet, @Guruh, @FIO, @Pasport_malumoti, @Otasi, @Onasi, @Tel_raqami, @Nechanchi_kurs)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox3.Text);
            cmd.Parameters.AddWithValue("@Guruh", comboBox4.Text);
            cmd.Parameters.AddWithValue("@FIO", textBox3.Text);
            cmd.Parameters.AddWithValue("@Pasport_malumoti", textBox4.Text);
            cmd.Parameters.AddWithValue("@Otasi", textBox5.Text);
            cmd.Parameters.AddWithValue("@Onasi", textBox6.Text);
            cmd.Parameters.AddWithValue("@Tel_raqami", textBox7.Text);
            cmd.Parameters.AddWithValue("@Nechanchi_kurs", textBox8.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Tanlangan qator haqiqiyligini tekshirish
            {
                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];

                comboBox3.Text = row.Cells[1].Value == null ? "" : row.Cells[1].Value.ToString();
                comboBox4.Text = row.Cells[2].Value == null ? "" : row.Cells[2].Value.ToString();
                textBox3.Text = row.Cells[3].Value == null ? "" : row.Cells[3].Value.ToString();
                textBox4.Text = row.Cells[4].Value == null ? "" : row.Cells[4].Value.ToString();
                textBox5.Text = row.Cells[5].Value == null ? "" : row.Cells[5].Value.ToString();
                textBox6.Text = row.Cells[6].Value == null ? "" : row.Cells[6].Value.ToString();
                textBox7.Text = row.Cells[7].Value == null ? "" : row.Cells[7].Value.ToString();
                textBox8.Text = row.Cells[8].Value == null ? "" : row.Cells[8].Value.ToString();
            }
        }
        private void button12_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "UPDATE Talabalar SET Fakultet=@Fakultet, Guruh=@Guruh, FIO=@FIO, Pasport_malumoti=@Pasport_malumoti, Otasi=@Otasi, Onasi=@Onasi, Tel_raqami=@Tel_raqami, Nechanchi_kurs=@Nechanchi_kurs WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox3.Text);
            cmd.Parameters.AddWithValue("@Guruh", comboBox4.Text);
            cmd.Parameters.AddWithValue("@FIO", textBox3.Text);
            cmd.Parameters.AddWithValue("@Pasport_malumoti", textBox4.Text);
            cmd.Parameters.AddWithValue("@Otasi", textBox5.Text);
            cmd.Parameters.AddWithValue("@Onasi", textBox6.Text);
            cmd.Parameters.AddWithValue("@Tel_raqami", textBox7.Text);
            cmd.Parameters.AddWithValue("@Nechanchi_kurs", textBox8.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        private void button13_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Talabalar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        //Fanlar   Fanlar   Fanlar
        private void Fanguruh(string fakultet)
        {
            string query = "SELECT Guruh FROM Fakultet WHERE Fakultet = @fakultet";
            OleDbCommand command = new OleDbCommand(query, con);
            command.Parameters.AddWithValue("@fakultet", fakultet);
            OleDbDataAdapter adapter = new OleDbDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox6.DataSource = table;
            comboBox6.DisplayMember = "Guruh";
            comboBox6.ValueMember = "Guruh";
        }
        private void FanFakultet()
        {
            con.Open();
            string query = "SELECT DISTINCT Fakultet FROM Fakultet";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox5.DataSource = table;
            comboBox5.DisplayMember = "Fakultet";
            comboBox5.ValueMember = "Fakultet";
            con.Close();
        }
        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox5.SelectedValue != null)
            {
                string fanFakultet = comboBox5.SelectedValue.ToString();
                Fanguruh(fanFakultet);
            }
        }
        private void button14_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Fanlar (Fakultet, Guruh, Fan_nomi, Kredit_soni) VALUES (@Fakultet, @Guruh, @Fan_nomi, @Kredit_soni)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox5.Text);
            cmd.Parameters.AddWithValue("@Guruh", comboBox6.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", textBox9.Text);
            cmd.Parameters.AddWithValue("@Kredit_soni", textBox10.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void button15_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "UPDATE Fanlar SET Fakultet=@Fakultet, Guruh=@Guruh, Fan_nomi=@Fan_nomi, Kredit_soni=@Kredit_soni WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox5.Text);
            cmd.Parameters.AddWithValue("@Guruh", comboBox6.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", textBox9.Text);
            cmd.Parameters.AddWithValue("@Kredit_soni", textBox10.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void button16_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Fanlar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Tanlangan qator haqiqiyligini tekshirish
            {
                DataGridViewRow row = dataGridView3.Rows[e.RowIndex];

                comboBox5.Text = row.Cells[1].Value == null ? "" : row.Cells[1].Value.ToString();
                comboBox6.Text = row.Cells[2].Value == null ? "" : row.Cells[2].Value.ToString();
                textBox9.Text = row.Cells[3].Value == null ? "" : row.Cells[3].Value.ToString();
                textBox10.Text = row.Cells[4].Value == null ? "" : row.Cells[4].Value.ToString();
            }
        }
        //O'qituvchilar   O'qituvchilar   O'qituvchilar
        private void button17_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Uqituvchilar (Uqituvchi_FIO, Fan_nomi) VALUES (@Uqituvchi_FIO, @Fan_nomi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Uqituvchi_FIO", textBox11.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", comboBox7.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        private void button18_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView4.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView4.Rows[index].Cells[0].Value);
            string query = "UPDATE Uqituvchilar SET Uqituvchi_FIO=@Uqituvchi_FIO, Fan_nomi=@Fan_nomi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Uqituvchi_FIO", textBox11.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", comboBox7.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        private void button19_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView4.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView4.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Uqituvchilar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Tanlangan qator haqiqiyligini tekshirish
            {
                DataGridViewRow row = dataGridView4.Rows[e.RowIndex];
                textBox11.Text = row.Cells[1].Value == null ? "" : row.Cells[1].Value.ToString();
                comboBox7.Text = row.Cells[2].Value == null ? "" : row.Cells[2].Value.ToString();
            }
        }
        //Talabani baholash    Talabani baholash
        private void Tal_baho_guruh(string fakultet)
        {
            string query = "SELECT Guruh FROM Fakultet WHERE Fakultet = @fakultet";
            OleDbCommand command = new OleDbCommand(query, con);
            command.Parameters.AddWithValue("@fakultet", fakultet);
            OleDbDataAdapter adapter = new OleDbDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox9.DataSource = table;
            comboBox9.DisplayMember = "Guruh";
            comboBox9.ValueMember = "Guruh";
        }
        private void Tal_baho_Fakultet()
        {
            con.Open();
            string query = "SELECT DISTINCT Fakultet FROM Fakultet";
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox8.DataSource = table;
            comboBox8.DisplayMember = "Fakultet";
            comboBox8.ValueMember = "Fakultet";
            con.Close();
        }
        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox8.SelectedValue != null)
            {
                string fanFakultet = comboBox8.SelectedValue.ToString();
                Tal_baho_guruh(fanFakultet);
            }
        }
        private void button20_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Talabani_baholash (Fakultet, Guruh, FIO, Fan_nomi, Uqituvchi, Ball) VALUES (@Fakultet, @Guruh, @FIO, @Fan_nomi, @Uqituvchi, @Ball)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox8.Text);
            cmd.Parameters.AddWithValue("@Guruh", comboBox9.Text);
            cmd.Parameters.AddWithValue("@FIO", textBox12.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", textBox13.Text);
            cmd.Parameters.AddWithValue("@Uqituvchi", textBox14.Text);
            cmd.Parameters.AddWithValue("@Ball", textBox15.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display5();
        }
        private void button21_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView5.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView5.Rows[index].Cells[0].Value);
            string query = "UPDATE Talabani_baholash SET Fakultet=@Fakultet, Guruh=@Guruh, FIO=@FIO, Fan_nomi=@Fan_nomi, Uqituvchi=@Uqituvchi, Ball=@Ball WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet", comboBox8.Text);
            cmd.Parameters.AddWithValue("@Guruh", comboBox9.Text);
            cmd.Parameters.AddWithValue("@FIO", textBox12.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", textBox13.Text);
            cmd.Parameters.AddWithValue("@Uqituvchi", textBox14.Text);
            cmd.Parameters.AddWithValue("@Ball", textBox15.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display5();
        }
        private void button22_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView5.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView5.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Talabani_baholash WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display5();
        }
        private void dataGridView5_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Tanlangan qator haqiqiyligini tekshirish
            {
                DataGridViewRow row = dataGridView5.Rows[e.RowIndex];
                comboBox8.Text = row.Cells[1].Value == null ? "" : row.Cells[1].Value.ToString();
                comboBox9.Text = row.Cells[2].Value == null ? "" : row.Cells[2].Value.ToString();
                textBox12.Text = row.Cells[3].Value == null ? "" : row.Cells[3].Value.ToString();
                textBox13.Text = row.Cells[4].Value == null ? "" : row.Cells[4].Value.ToString();
                textBox14.Text = row.Cells[5].Value == null ? "" : row.Cells[5].Value.ToString();
                textBox15.Text = row.Cells[6].Value == null ? "" : row.Cells[6].Value.ToString();
            }
        }        
    }
}
