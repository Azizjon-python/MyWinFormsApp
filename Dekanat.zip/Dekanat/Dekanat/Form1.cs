﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Dekanat
{
    public partial class Form1 : Form
    {
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Dekanat.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            display1();
            display2();
            display3();
            display4();
            fakultetid();
            guruh();
            talaba();
        }
        void display1()
        {
            con.Open();
            string query = "SELECT * FROM Baholar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        void display2()
        {
            con.Open();
            string query = "SELECT * FROM Fakultetlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        void display3()
        {
            con.Open();
            string query = "SELECT * FROM Guruh";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView3.DataSource = dt;
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        void display4()
        {
            con.Open();
            string query = "SELECT * FROM Talabalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView4.DataSource = dt;
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        //Fakultet
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Fakultetlar (Fakultet_nomi) VALUES (@Fakultet_nomi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet_nomi", textBox1.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
            fakultetid();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "UPDATE Fakultetlar SET Fakultet_nomi=@Fakultet_nomi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Fakultet_nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Fakultetlar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
        }
        //Guruh
        void fakultetid()
        {
            con.Open();
            string query = "SELECT * FROM Fakultetlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "Fakultet_nomi";
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Guruh (Guruh_nomi, Fakultet_id) VALUES (@Guruh_nomi, @Fakultet_id)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Guruh_nomi", textBox2.Text);
            cmd.Parameters.AddWithValue("@Fakultet_id", comboBox1.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
            guruh();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "UPDATE Guruh SET Guruh_nomi=@Guruh_nomi, Fakultet_id=@Fakultet_id WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Guruh_nomi", textBox2.Text);
            cmd.Parameters.AddWithValue("@Fakultet_id", comboBox1.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Guruh WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        //Talabalar
        void guruh()
        {
            con.Open();
            string query = "SELECT * FROM Guruh";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox2.DataSource = dt;
            comboBox2.ValueMember = "Guruh_nomi";
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
            display3();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Talabalar (Ism_Familiya, Tugilgan_sanasi, Jinsi, Guruh_id) VALUES (@Ism_Familiya, @Tugilgan_sanasi, @Jinsi, @Guruh_id)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism_Familiya", textBox3.Text);
            cmd.Parameters.AddWithValue("@Tugilgan_sanasi", dateTimePicker1.Value);
            bool gender = radioButton1.Checked ? radioButton1.Checked : radioButton2.Checked != true ? radioButton2.Checked : false;
            cmd.Parameters.AddWithValue("@Jinsi", gender);
            cmd.Parameters.AddWithValue("@Guruh_id", comboBox2.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
            talaba();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView4.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView4.Rows[index].Cells[0].Value);
            string query = "UPDATE Talabalar SET Ism_Familiya=@Ism_Familiya, Tugilgan_sanasi=@Tugilgan_sanasi, Jinsi=@Jinsi, Guruh_id=@Guruh_id WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Ism_Familiya", textBox3.Text);
            cmd.Parameters.AddWithValue("@Tugilgan_sanasi", dateTimePicker1.Value);
            bool gender = radioButton1.Checked ? radioButton1.Checked : radioButton2.Checked != true ? radioButton2.Checked : false;
            cmd.Parameters.AddWithValue("@Jinsi", gender);
            cmd.Parameters.AddWithValue("@Guruh_id", comboBox2.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView4.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView4.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Talabalar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display4();
        }
        //Baholar
        void talaba()
        {
            con.Open();
            string query = "SELECT * FROM Talabalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox3.DataSource = dt;
            comboBox3.ValueMember = "Ism_Familiya";
            cmd.Dispose();
            adapter.Dispose();
            con.Close();
            display4();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Baholar (Talaba_id, Fan_nomi, Baho, imtihon_sanasi) VALUES (@Talaba_id, @Fan_nomi, @Baho, @imtihon_sanasi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Talaba_id", comboBox3.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", textBox4.Text);
            cmd.Parameters.AddWithValue("@Baho", textBox5.Text);
            cmd.Parameters.AddWithValue("@imtihon_sanasi", dateTimePicker2.Value);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void button11_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Baholar SET Talaba_id=@Talaba_id, Fan_nomi=@Fan_nomi, Baho=@Baho, imtihon_sanasi=@imtihon_sanasi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Talaba_id", comboBox3.Text);
            cmd.Parameters.AddWithValue("@Fan_nomi", textBox4.Text);
            cmd.Parameters.AddWithValue("@Baho", textBox5.Text);
            cmd.Parameters.AddWithValue("@imtihon_sanasi", dateTimePicker2.Value);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void button12_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Baholar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
        }
        private void button13_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }
        private void button14_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }
        private void button15_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }
        private void button16_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage5;
        }
        private void button20_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }
        private void button19_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }
        private void button18_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }
        private void button17_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }
    }
}
