﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace KursIshi
{
    public partial class Form1 : Form
    {
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Kursishi.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            display();
            panel1.Visible = false;
            buyutmachi();
            mahsulot();
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Buyurtma_tafsilotlari";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            con.Close();
        }
        void buyutmachi()
        {
            con.Open();
            string query = "SELECT Mijoz_ID FROM Buyurtmalar WHERE Buyurtma_statusi = 'Tayyor'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Mijoz_ID";
            comboBox1.ValueMember = "Mijoz_ID";
            con.Close();
        }
        void mahsulot()
        {
            con.Open();
            string query = "SELECT * FROM Mahsulotlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = "Mahsulot_nomi";
            comboBox2.ValueMember = "Mahsulot_nomi";
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Buyurtmalar buyurtmalar = new Buyurtmalar();
            buyurtmalar.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Mahsulotlar mahsulot = new Mahsulotlar();
            mahsulot.Show();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Materiallar materiallar = new Materiallar();
            materiallar.Show();
            this.Hide();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Mijozlar mijozlar = new Mijozlar();
            mijozlar.Show();
            this.Hide();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Xodimlarcs xodimlarcs = new Xodimlarcs();
            xodimlarcs.Show();
            this.Hide();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            panel1.Visible = !panel1.Visible;
        }       
        private void CalculateTotalPrice()
        {
            // Agar ComboBox yoki TextBox bo'sh bo'lsa, qaytish
            if (comboBox2.SelectedItem == null || string.IsNullOrWhiteSpace(textBox1.Text))
            {
                textBox2.Clear();
                return;
            }

            // TextBox1'ga kiritilgan miqdorni tekshirish
            decimal miqdor;
            if (!decimal.TryParse(textBox1.Text, out miqdor))
            {
                MessageBox.Show("Iltimos, miqdorni to'g'ri kiriting!", "Xato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                con.Open();
                string query = "SELECT Narx FROM Mahsulotlar WHERE Mahsulot_nomi = @Mahsulot_nomi";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@Mahsulot_nomi", comboBox2.Text);

                object result = cmd.ExecuteScalar();
                con.Close();

                decimal narx;
                if (result != null && decimal.TryParse(result.ToString(), out narx))
                {
                    // Narx va miqdorni ko'paytirib TextBox2'ga chiqarish
                    textBox2.Text = (narx * miqdor).ToString("F2");
                }
                else
                {
                    MessageBox.Show("Tanlangan mahsulot uchun narx topilmadi!", "Xato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik yuz berdi: " + ex.Message, "Xato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculateTotalPrice();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            CalculateTotalPrice();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Buyurtma_tafsilotlari (Buyurtmachi, Mahsulot_nomi, Mahsulot_miqdori, Umumiy_narx) VALUES (@Buyurtmachi, @Mahsulot_nomi, @Mahsulot_miqdori, @Umumiy_narx)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Buyurtmachi", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Mahsulot_nomi", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Mahsulot_miqdori", textBox1.Text);
            cmd.Parameters.AddWithValue("@Umumiy_narx", textBox2.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Buyurtma_tafsilotlari (Buyurtmachi, Mahsulot_nomi, Mahsulot_miqdori, Umumiy_narx) VALUES (@Buyurtmachi, @Mahsulot_nomi, @Mahsulot_miqdori, @Umumiy_narx)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Buyurtmachi", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Mahsulot_nomi", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Mahsulot_miqdori", textBox1.Text);
            cmd.Parameters.AddWithValue("@Umumiy_narx", textBox2.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
    }
}
