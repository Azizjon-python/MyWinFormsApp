﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace KursIshi
{
    public partial class Mahsulotlar : Form
    {
        OleDbConnection con;
        public Mahsulotlar()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Kursishi.mdb");
        }
        void display()
        {
            con.Open();
            string query = "Select * from Mahsulotlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            con.Close();
        }
        private void Mahsulotlar_Load(object sender, EventArgs e)
        {
            display();
            material();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert into Mahsulotlar (Mahsulot_nomi, Material_turi, Material_miqdori, Narx) values (@Mahsulot_nomi, @Material_turi, @Material_miqdori, @Narx)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Mahsulot_nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@Material_turi", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Material_miqdori", textBox2.Text);
            cmd.Parameters.AddWithValue("@Narx", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        void material()
        {
            con.Open();
            string query = "Select * from Materiallar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Material_nomi";
            adapter.Dispose();
            con.Close();
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            CalculatePrice();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculatePrice();
        }
        private void CalculatePrice()
        {
            if (comboBox1.SelectedItem == null || string.IsNullOrWhiteSpace(textBox2.Text))
            {
                textBox3.Clear();
                return;
            }

            decimal materialMiqdori;
            if (!decimal.TryParse(textBox2.Text, out materialMiqdori))
            {
                MessageBox.Show("Iltimos, miqdorni to'g'ri kiriting!", "Xato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            con.Open();
            OleDbCommand cmd = new OleDbCommand("Select Narxi from Materiallar where Material_nomi = @Material_nomi", con);
            cmd.Parameters.AddWithValue("@Material_nomi", comboBox1.Text);
            var result = cmd.ExecuteScalar();
            con.Close();

            if (result != null)
            {
                decimal materialNarxi;
                if (decimal.TryParse(result.ToString(), out materialNarxi))
                {
                    textBox3.Text = (materialNarxi * materialMiqdori).ToString("F2");
                }
            }
            else
            {
                MessageBox.Show("Tanlangan material uchun narx topilmadi!", "Xato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "Update Mahsulotlar set Mahsulot_nomi=@Mahsulot_nomi, Material_turi=@Material_turi, Material_miqdori=@Material_miqdori, Narx=@Narx where Mahsulot_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Mahsulot_nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@Material_turi", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Material_miqdori", textBox2.Text);
            cmd.Parameters.AddWithValue("@Narx", textBox3.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int index = dataGridView1.CurrentRow.Index;
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells[1].Value.ToString();
                comboBox1.Text = row.Cells[2].Value.ToString();
                textBox2.Text = row.Cells[3].Value.ToString();
                //textBox3.Text = row.Cells[4].Value.ToString();
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
