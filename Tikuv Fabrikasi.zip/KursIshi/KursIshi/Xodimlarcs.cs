﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Reflection;

namespace KursIshi
{
    public partial class Xodimlarcs : Form
    {
        OleDbConnection con;
        public Xodimlarcs()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Kursishi.mdb");
        }
        private void Xodimlarcs_Load(object sender, EventArgs e)
        {
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        void display()
        {
            con.Open();
            string query = "select * from Xodimlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert into Xodimlar ([FIO], [Lavozim], [Ishga_kirgan_sanasi], [Oylik_maosh]) values (@FIO, @Lavozim, @Ishga_kirgan_sanasi, @Oylik_maosh)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@FIO", textBox1.Text);
            cmd.Parameters.AddWithValue("@Lavozim", textBox2.Text);
            cmd.Parameters.Add("@Ishga_kirgan_sanasi", OleDbType.DBDate).Value=dateTimePicker1.Value;
            cmd.Parameters.AddWithValue("@Oylik_maosh", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "Update Xodimlar set FIO=@FIO, Lavozim=@Lavozim, Ishga_kirgan_sanasi=@Ishga_kirgan_sanasi, Oylik_maosh=@Oylik_maosh where Xodim_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@FIO", textBox1.Text);
            cmd.Parameters.AddWithValue("@Lavozim", textBox2.Text);
            cmd.Parameters.Add("@Ishga_kirgan_sanasi", OleDbType.DBDate).Value = dateTimePicker1.Value;
            cmd.Parameters.AddWithValue("@Oylik_maosh", textBox3.Text);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "Delete from Xodimlar where Xodim_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridView1.CurrentRow.Index;
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            textBox1.Text = row.Cells["FIO"].Value.ToString();
            textBox2.Text = row.Cells["Lavozim"].Value.ToString();
            textBox3.Text = row.Cells["Oylik_maosh"].Value.ToString();
            dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[index].Cells[3].Value);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
