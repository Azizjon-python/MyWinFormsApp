﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace KursIshi
{
    public partial class Materiallar : Form
    {
        OleDbConnection con;

        public Materiallar()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Kursishi.mdb");
        }

        private void Materiallar_Load(object sender, EventArgs e)
        {
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Materiallar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Materiallar ([Material_nomi], [Umumiy_miqdori], [Narxi]) VALUES (@Material_nomi, @Umumiy_miqdori, @Narxi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Material_nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@Umumiy_miqdori", textBox2.Text);
            cmd.Parameters.AddWithValue("@Narxi", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Material_ID"].Value);
            string query = "Update Materiallar set Material_nomi=@Material_nomi, Umumiy_miqdori=@Umumiy_miqdori, Narxi=@Narxi where Material_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Material_nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@Umumiy_miqdori", textBox2.Text);
            cmd.Parameters.AddWithValue("@Narxi", textBox3.Text);
            cmd.Parameters.AddWithValue("@ID", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        // Qatorni tanlanganda textboxlarga ma'lumot yuklash
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Material_nomi"].Value.ToString();
                textBox2.Text = row.Cells["Umumiy_miqdori"].Value.ToString();
                textBox3.Text = row.Cells["Narxi"].Value.ToString();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Material_ID"].Value);
            string query = "Delete from Materiallar where Material_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ID", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
