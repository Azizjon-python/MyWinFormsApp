﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace KursIshi
{
    public partial class Mijozlar : Form
    {
        OleDbConnection con;
        public Mijozlar()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Kursishi.mdb");
        }
        void display()
        {
            con.Open();
            string query = "Select * from Mijozlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void Mijozlar_Load(object sender, EventArgs e)
        {
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert into Mijozlar (Mijoz_FIO, Telefon_raqami, Manzil) values (@Mijoz_FIO, @Telefon_raqami, @Manzil)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Mijoz_FIO", textBox1.Text);
            cmd.Parameters.AddWithValue("@Telefon_raqami", textBox2.Text);
            cmd.Parameters.AddWithValue("@Manzil", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "Update Mijozlar set Mijoz_FIO=@Mijoz_FIO, Telefon_raqami=@Telefon_raqami, Manzil=@Manzil where Mijoz_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Mijoz_FIO", textBox1.Text);
            cmd.Parameters.AddWithValue("@Telefon_raqami", textBox2.Text);
            cmd.Parameters.AddWithValue("@Manzil", textBox3.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Mijoz_FIO"].Value.ToString();
                textBox2.Text = row.Cells["Telefon_raqami"].Value.ToString();
                textBox3.Text = row.Cells["Manzil"].Value.ToString();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "Delete from Mijozlar where Mijoz_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            search();
        }
        void search()
        {
            if (dataGridView1 != null)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = string.Format("Mijoz_FIO Like'%" + textBox4.Text + "%'");
            }
        }
    }
}
