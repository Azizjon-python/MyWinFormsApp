﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection;

namespace KursIshi
{
    public partial class Buyurtmalar : Form
    {
        OleDbConnection con;
        public Buyurtmalar()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Kursishi.mdb");
        }

        private void Buyurtmalar_Load(object sender, EventArgs e)
        {
            display();
            combobox1();
            comboBox2.Items.Add("Jarayonda");
            comboBox2.Items.Add("Tayyor");
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        void display()
        {
            con.Open();
            string query = "Select * from Buyurtmalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert into Buyurtmalar ([Mijoz_ID], [Buyurtma_sanasi], [Buyurtma_statusi], [Jami_narx]) values (@Mijoz_ID, @Buyurtma_sanasi, @Buyurtma_statusi, @Jami_narx)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("Mijoz_ID", comboBox1.Text);
            cmd.Parameters.AddWithValue("Buyurtma_sanasi", dateTimePicker1.Value);
            string selectedItem1 = comboBox2.SelectedItem != null ? comboBox2.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@Buyurtma_statusi", selectedItem1);
            cmd.Parameters.AddWithValue("Jami_narx", textBox1.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        void combobox1()
        {
            con.Open();
            string query = "Select * from Mijozlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember="Mijoz_FIO";
            
            adapter.Dispose();
            con.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "Update Buyurtmalar set Mijoz_ID=@Mijoz_ID, Buyurtma_sanasi=@Buyurtma_sanasi, Buyurtma_statusi=@Buyurtma_statusi, Jami_narx=@Jami_narx where Buyurtma_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("Mijoz_ID", comboBox1.Text);
            cmd.Parameters.AddWithValue("Buyurtma_sanasi", dateTimePicker1.Value);
            string selectedItem1 = comboBox2.SelectedItem != null ? comboBox2.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@Buyurtma_statusi", selectedItem1);
            cmd.Parameters.AddWithValue("Jami_narx", textBox1.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "Delete from Buyurtmalar where Buyurtma_ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int index = dataGridView1.CurrentRow.Index;
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                comboBox1.Text = row.Cells[1].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[index].Cells[2].Value);
                comboBox2.Text = row.Cells[3].Value.ToString();
                textBox1.Text = row.Cells[4].Value.ToString();
                
            }
        }
    }
}
