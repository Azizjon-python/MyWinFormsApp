﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Avtobus
{
    public partial class Form1 : Form
    {
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/Lenova/Desktop/Avtobus Parki.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            display1();
            display2();
            display3();
            avtobus();
            haydovchi();
            panel1.Visible = false;
            dataGridView3.CellClick += new DataGridViewCellEventHandler(dataGridView3_CellContentClick);
            dataGridView2.CellClick += new DataGridViewCellEventHandler(dataGridView2_CellContentClick);
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }
        void display1()
        {
            con.Open();
            string query = "Select * from Avtobus";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display2()
        {
            con.Open();
            string query = "Select * from Haydovchi";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display3()
        {
            con.Open();
            string query = "Select * from Mashrut";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView3.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        //Avtobus
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert into Avtobus (davlat_raqami, turi, yolovchi_sigimi) values (@davlat_raqami, @turi, @yolovchi_sigimi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@davlat_raqami", textBox1.Text);
            cmd.Parameters.AddWithValue("@turi", textBox2.Text);
            cmd.Parameters.AddWithValue("@yolovchi_sigimi", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
            avtobus();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "Update Avtobus set davlat_raqami=@davlat_raqami, turi=@turi, yolovchi_sigimi=@yolovchi_sigimi where id=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@davlat_raqami", textBox1.Text);
            cmd.Parameters.AddWithValue("@turi", textBox2.Text);
            cmd.Parameters.AddWithValue("@yolovchi_sigimi", textBox3.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
            avtobus();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "Delete from Avtobus where id=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display1();
            avtobus();
        }
        //Haydovchi
        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert into Haydovchi (familiya, ism, sharif, jinsi, maoshi, sinfi) values (@familiya, @ism, @sharif, @jinsi, @maoshi, @sinfi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@familiya", textBox8.Text);
            cmd.Parameters.AddWithValue("@ism", textBox7.Text);
            cmd.Parameters.AddWithValue("@sharif", textBox6.Text);
            bool jinsi = radioButton1.Checked ? radioButton1.Checked : radioButton2.Checked != true ? radioButton2.Checked : false;
            cmd.Parameters.AddWithValue("@jinsi", jinsi);
            cmd.Parameters.AddWithValue("@maoshi", textBox5.Text);
            cmd.Parameters.AddWithValue("@sinfi", textBox4.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose ();
            con.Close();
            display2();
            haydovchi();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "Update Haydovchi set familiya=@familiya, ism=@ism, sharif=@sharif, jinsi=@jinsi, maoshi=@maoshi, sinfi=@sinfi where id=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@familiya", textBox8.Text);
            cmd.Parameters.AddWithValue("@ism", textBox7.Text);
            cmd.Parameters.AddWithValue("@sharif", textBox6.Text);
            bool jinsi = radioButton1.Checked ? radioButton1.Checked : radioButton2.Checked != true ? radioButton2.Checked : false;
            cmd.Parameters.AddWithValue("@jinsi", jinsi);
            cmd.Parameters.AddWithValue("@maoshi", textBox5.Text);
            cmd.Parameters.AddWithValue("@sinfi", textBox4.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
            haydovchi();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            string query = "Delete from Haydovchi where id=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display2();
            haydovchi();
        }
        //Mashrut
        void avtobus()
        {
            con.Open();
            string query = "Select * from Avtobus";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "turi";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void haydovchi()
        {
            con.Open();
            string query = "Select * from Haydovchi";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox2.DataSource = dt;
            comboBox2.ValueMember = "ism";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert into Mashrut (nomer, boshlanish, yakunlanish, vaqt, avtobus, haydovchi) values (@nomer, @boshlanish, @yakunlanish, @vaqt, @avtobus, @haydovchi)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@nomer", textBox11.Text);
            cmd.Parameters.AddWithValue("@boshlanish", textBox10.Text);
            cmd.Parameters.AddWithValue("@yakunlanish", textBox9.Text);
            cmd.Parameters.AddWithValue("@vaqt", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@avtobus", comboBox1.Text);
            cmd.Parameters.AddWithValue("@haydovchi", comboBox2.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "Update Mashrut set nomer=@nomer, boshlanish=@boshlanish, yakunlanish=@yakunlanish, vaqt=@vaqt, avtobus=@avtobus, haydovchi=@haydovchi where id=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@nomer", textBox11.Text);
            cmd.Parameters.AddWithValue("@boshlanish", textBox10.Text);
            cmd.Parameters.AddWithValue("@yakunlanish", textBox9.Text);
            cmd.Parameters.AddWithValue("@vaqt", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@avtobus", comboBox1.Text);
            cmd.Parameters.AddWithValue("@haydovchi", comboBox2.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            string query = "Delete from Mashrut where id=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display3();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            textBox1.Text = dataGridView1.Rows[index].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[index].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[index].Cells[3].Value.ToString();
        }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridView2.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
            textBox8.Text = dataGridView2.Rows[index].Cells[1].Value.ToString();
            textBox7.Text = dataGridView2.Rows[index].Cells[2].Value.ToString();
            textBox6.Text = dataGridView2.Rows[index].Cells[3].Value.ToString();
            textBox5.Text = dataGridView2.Rows[index].Cells[4].Value.ToString();
            textBox4.Text = dataGridView2.Rows[index].Cells[5].Value.ToString();
        }
        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridView3.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
            textBox11.Text = dataGridView3.Rows[index].Cells[1].Value.ToString();
            textBox10.Text = dataGridView3.Rows[index].Cells[2].Value.ToString();
            textBox9.Text = dataGridView3.Rows[index].Cells[3].Value.ToString();
            dateTimePicker1.Value = Convert.ToDateTime(dataGridView3.Rows[index].Cells[4].Value.ToString());
            comboBox1.Text = dataGridView3.Rows[index].Cells[5].Value.ToString();
            comboBox2.Text = dataGridView3.Rows[index].Cells[6].Value.ToString();
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            string parol = textBox12.Text;
            if(parol == "hamidullo")
            {
                panel1.Visible = !panel1.Visible;
            }
            else
            {
                MessageBox.Show("Parol xato kiritildi \n Qaytadan urunib ko'ring!");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }
    }
}
