﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Avtomobillar
{
    public partial class Form1 : Form
    {
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Avtomobillar/Avtomobil.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            display();
            display2();
            display3();
            display4();
            panel2.Visible = true;
            panel1.Visible = false;
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM BoshSahifa";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataadapter.Fill(dt);
            dataGridView1.DataSource = dt;
            dataadapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display2()
        {
            con.Open();
            string query = "SELECT EgasiID, Familiya_Ism FROM Egalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataadapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "EgasiID";
            comboBox1.DisplayMember = "Familiya_Ism";
            dataadapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display3()
        {
            con.Open();
            string query = "SELECT * FROM Raqamlar WHERE RaqamHolati='Aktiv'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataadapter.Fill(dt);
            comboBox2.DataSource = dt;
            comboBox2.ValueMember = "RaqamID";
            comboBox2.DisplayMember = "DavlatRaqami";
            dataadapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        void display4()
        {
            con.Open();
            string query = "SELECT * FROM Avtomobillar WHERE Bandligi='band_emas'";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataadapter.Fill(dt);
            comboBox3.DataSource = dt;
            comboBox3.ValueMember = "AvtoID";
            comboBox3.DisplayMember = "Modeli";
            dataadapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        // RaqamID ni olish
        private int returnId(string raqam)
        {
            int raqamid = -1;
            con.Open();
            string query = "SELECT RaqamID FROM Raqamlar WHERE DavlatRaqami = @DavlatRaqami";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@DavlatRaqami", raqam);
            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                raqamid = Convert.ToInt32(result);
            }
            cmd.Dispose();
            con.Close();
            return raqamid;
        }
        // AvtoID ni olish
        private int returnId1(string avto)
        {
            int avtoid = -1;
            con.Open();
            string query = "SELECT AvtoID FROM Avtomobillar WHERE Modeli = @Modeli";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Modeli", avto);
            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                avtoid = Convert.ToInt32(result);
            }
            cmd.Dispose();
            con.Close();
            return avtoid;
        }
        // Ma'lumot qo'shish
        private void button8_Click(object sender, EventArgs e)
        {
            string raqam = comboBox2.Text;
            int raqam1 = returnId(raqam);
            string avto = comboBox3.Text;
            int avto1 = returnId1(avto);
            try
            {
                if (comboBox1.SelectedValue == null || comboBox2.SelectedValue == null || comboBox3.SelectedValue == null)
                {
                    MessageBox.Show("Iltimos, egasini, raqamni va avtomobilni tanlang.");
                    return;
                }
                string EgasiIsmi = comboBox1.Text;
                con.Open();
                string query = "INSERT INTO BoshSahifa ([AvtomobilEgasi], [RaqamID], [AvtoID], [Biriktirilgan_Sana]) VALUES (@AvtomobilEgasi, @RaqamID, @AvtoID, @Biriktirilgan_Sana)";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@AvtomobilEgasi", EgasiIsmi);
                cmd.Parameters.AddWithValue("@RaqamID", raqam1);
                cmd.Parameters.AddWithValue("@AvtoID", avto1);
                cmd.Parameters.AddWithValue("@Biriktirilgan_Sana", Sana.Value);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                string updateRaqamQuery = "UPDATE Raqamlar SET RaqamHolati='Band' WHERE RaqamID=@RaqamID";
                OleDbCommand updateRaqamCmd = new OleDbCommand(updateRaqamQuery, con);
                updateRaqamCmd.Parameters.AddWithValue("@RaqamID", raqam1);
                updateRaqamCmd.ExecuteNonQuery();
                //string updateAvtoQuery = "UPDATE Avtomobillar SET Bandligi='Band' WHERE AvtoID=@AvtoID";
                //OleDbCommand updateAvtoCmd = new OleDbCommand(updateAvtoQuery, con);
                //updateAvtoCmd.Parameters.AddWithValue("@AvtoID", avto1);
                //updateAvtoCmd.ExecuteNonQuery();
                updateRaqamCmd.Dispose();
                //updateAvtoCmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik yuz berdi: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
                display2();
                display3();
                display4();
            }
        }
        // Ma'lumotni o'zgartirish
        private void button7_Click(object sender, EventArgs e)
        {
                if (comboBox1.SelectedValue == null || comboBox2.SelectedValue == null || comboBox3.SelectedValue == null)
                {
                    MessageBox.Show("Iltimos, egasini, raqamni va avtomobilni tanlang.");
                    return;
                }
                string EgasiIsmi = comboBox1.Text;
                int RaqamID = Convert.ToInt32(comboBox2.SelectedValue);
                int AvtoID = Convert.ToInt32(comboBox3.SelectedValue);
                if (dataGridView1.CurrentRow != null)
                {
                    int oldRaqamID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["RaqamID"].Value);
                    con.Open();
                    int index = dataGridView1.CurrentRow.Index;
                    int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
                    string query = "UPDATE BoshSahifa SET AvtomobilEgasi=@AvtomobilEgasi, RaqamID=@RaqamID, AvtoID=@AvtoID, Biriktirilgan_Sana=@Biriktirilgan_Sana WHERE ID=@id";
                    OleDbCommand cmd = new OleDbCommand(query, con);
                    cmd.Parameters.AddWithValue("@AvtomobilEgasi", EgasiIsmi);
                    cmd.Parameters.AddWithValue("@RaqamID", RaqamID);
                    cmd.Parameters.AddWithValue("@AvtoID", AvtoID);
                    cmd.Parameters.AddWithValue("@Biriktirilgan_Sana", Sana.Value);
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    if (oldRaqamID != RaqamID)
                    {
                        string updateOldXonaQuery = "UPDATE Raqamlar SET RaqamHolati = 'Aktiv' WHERE RaqamID = @RaqamID";
                        OleDbCommand updateOldCmd = new OleDbCommand(updateOldXonaQuery, con);
                        updateOldCmd.Parameters.AddWithValue("@XonaID", oldRaqamID);
                        updateOldCmd.ExecuteNonQuery();
                    }
                    // Yangi xonaning holatini 'band' qilish
                    string updateNewXonaQuery = "UPDATE Raqamlar SET RaqamHolati = 'Band' WHERE RaqamID = @RaqamID";
                    OleDbCommand updateNewCmd = new OleDbCommand(updateNewXonaQuery, con);
                    updateNewCmd.Parameters.AddWithValue("@XonaID", RaqamID);
                    updateNewCmd.ExecuteNonQuery();
                    
                }
                else
                {
                    MessageBox.Show("Iltimos, jadvaldan qator tanlang.");
                }
                con.Close();
                display();
                display2();
                display3();
                display4();
        }
        // Ma'lumotni o'chirish
        private void button9_Click(object sender, EventArgs e)
        {
            int RaqamID = Convert.ToInt32(comboBox2.SelectedValue);
            int oldRaqamID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["RaqamID"].Value);
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            // BoshSahifa jadvalidan o'chirish
            string query = "DELETE FROM BoshSahifa WHERE id=@ID";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            // O'chirilgan ma'lumotni Raqamlar va Avtomobillar jadvalidan yangilash
            if (oldRaqamID != RaqamID)
            {
                string updateOldXonaQuery = "UPDATE Raqamlar SET RaqamHolati = 'Aktiv' WHERE RaqamID = @RaqamID";
                OleDbCommand updateOldCmd = new OleDbCommand(updateOldXonaQuery, con);
                updateOldCmd.Parameters.AddWithValue("@XonaID", oldRaqamID);
                updateOldCmd.ExecuteNonQuery();
            }
            // Yangi xonaning holatini 'band' qilish
            string updateNewXonaQuery = "UPDATE Raqamlar SET RaqamHolati = 'Band' WHERE RaqamID = @RaqamID";
            OleDbCommand updateNewCmd = new OleDbCommand(updateNewXonaQuery, con);
            updateNewCmd.Parameters.AddWithValue("@XonaID", RaqamID);
            updateNewCmd.ExecuteNonQuery();
            con.Close();
            display();
            display2();
            display3();
            display4();
        }
        // Jadvaldagi qatorni bosgan paytda ma'lumotlarni ko'rsatish
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                    string EgasiIsmi = row.Cells["AvtomobilEgasi"].Value.ToString();
                    //int RaqamID = Convert.ToInt32(row.Cells["RaqamID"].Value);
                    int xonaID = row.Cells["RaqamID"].Value != null && row.Cells["RaqamID"].Value != DBNull.Value ? Convert.ToInt32(row.Cells["RaqamID"].Value) : -1;
                    string xonaRaqami = GetXonaRaqamiByID(xonaID);
                    comboBox2.Text = xonaRaqami;
                    int AvtoID = Convert.ToInt32(row.Cells["AvtoID"].Value);
                    Sana.Value = Convert.ToDateTime(row.Cells["Biriktirilgan_Sana"].Value);
                    comboBox1.Text = EgasiIsmi;
                    // comboBox2'ni yangilash (RaqamID ga mos)
                    //comboBox2.SelectedValue = RaqamID;
                    // comboBox3'ni yangilash (AvtoID ga mos)
                    comboBox3.SelectedValue = AvtoID;
                    int xonaID1 = row.Cells["AvtoID"].Value != null && row.Cells["AvtoID"].Value != DBNull.Value ? Convert.ToInt32(row.Cells["AvtoID"].Value) : -1;
                    string xonaRaqami1 = GetXonaRaqamiByID1(xonaID1);
                    comboBox3.Text = xonaRaqami1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik yuz berdi: " + ex.Message);
            }
        }
        // Panel ko'rsatish
        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = !panel1.Visible;
        }
        // Panel 2'ni ko'rsatish
        private void button5_Click(object sender, EventArgs e)
        {
            panel2.Visible = !panel2.Visible;
        }
        // Formni yopish
        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // Form2'ni ochish
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
        // Form3'ni ochish
        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        // Form4'ni ochish
        private void button4_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }
        private string GetXonaRaqamiByID(int xonaID)
        {
            string xonaRaqami = null;
            con.Open();
            string query = "SELECT DavlatRaqami FROM Raqamlar WHERE RaqamID = @RaqamID";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@RaqamID", xonaID);
            object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
            if (result != null)
            {
                // Agar XonaRaqami topilsa, uni qaytaramiz
                xonaRaqami = result.ToString();
            }
            cmd.Dispose();
            con.Close();
            return xonaRaqami;
        }
        private string GetXonaRaqamiByID1(int xonaID)
        {
            string xonaRaqami = null;
            con.Open();
            string query = "SELECT Modeli FROM Avtomobillar WHERE AvtoID = @AvtoID";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@AvtoID", xonaID);
            object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
            if (result != null)
            {
                // Agar XonaRaqami topilsa, uni qaytaramiz
                xonaRaqami = result.ToString();
            }
            cmd.Dispose();
            con.Close();
            return xonaRaqami;
        }
    }
}
