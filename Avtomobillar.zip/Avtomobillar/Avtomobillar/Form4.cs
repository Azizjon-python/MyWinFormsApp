﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Avtomobillar
{
    public partial class Form4 : Form
    {
        OleDbConnection con;
        public Form4()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Avtomobillar/Avtomobil.mdb");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Aktiv");
            comboBox1.Items.Add("Band");
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Raqamlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataadapter.Fill(dt);
            dataGridView1.DataSource = dt;
            dataadapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        //Qo'shish
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string a = "INSERT INTO Raqamlar ([DavlatRaqami], [RaqamHolati]) VALUES (@DavlatRaqami, @RaqamHolati)";
            OleDbCommand cmd = new OleDbCommand(a, con);
            cmd.Parameters.AddWithValue("@DavlatRaqami", textBox1.Text);
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@RaqamHolati", selectedItem);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //O'zgartirish
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE Raqamlar SET DavlatRaqami=@DavlatRaqami, RaqamHolati=@RaqamHolati WHERE RaqamID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@DavlatRaqami", textBox1.Text);
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@RaqamHolati", selectedItem);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //O'chirish
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Raqamlar WHERE RaqamID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //Ko'rsatish
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["DavlatRaqami"].Value.ToString();
                comboBox1.Text = row.Cells["RaqamHolati"].Value != null ? row.Cells["RaqamHolati"].Value.ToString() : ""; 
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik yuz berdi: " + ex.Message);
            }
        }
    }
}
