﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Avtomobillar
{
    public partial class Form3 : Form
    {
        OleDbConnection con;
        public Form3()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Avtomobillar/Avtomobil.mdb");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Egalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataadapter.Fill(dt);
            dataGridView1.DataSource = dt;
            dataadapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        //Qo'shish
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string a = "INSERT INTO Egalar ([Familiya_Ism], [PasportMalumot], [Tel_raqami]) VALUES (@Familiya_Ism, @PasportMalumot, @Tel_raqami)";
            OleDbCommand cmd = new OleDbCommand(a, con);
            cmd.Parameters.AddWithValue("@Familiya_Ism", textBox1.Text);
            cmd.Parameters.AddWithValue("@PasportMalumot", textBox2.Text);
            cmd.Parameters.AddWithValue("@Tel_raqami", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose ();
            con.Close();
            display();
        }
        //O'zgartirish
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string a = "UPDATE Egalar SET Familiya_Ism=@Familiya_Ism, PasportMalumot=@PasportMalumot, Tel_raqami=@Tel_raqami WHERE EgasiID=@id";
            OleDbCommand cmd = new OleDbCommand(a, con);
            cmd.Parameters.AddWithValue("@Familiya_Ism", textBox1.Text);
            cmd.Parameters.AddWithValue("@PasportMalumot", textBox2.Text);
            cmd.Parameters.AddWithValue("@Tel_raqami", textBox3.Text);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //O'chirish
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string a = "DELETE FROM Egalar WHERE EgasiID=@id";
            OleDbCommand cmd = new OleDbCommand(a, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            textBox1.Text = dataGridView1.Rows[index].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[index].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[index].Cells[3].Value.ToString();
        }
    }
}
