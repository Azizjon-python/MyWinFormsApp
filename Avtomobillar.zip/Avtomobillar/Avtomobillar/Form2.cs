﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace Avtomobillar
{
    public partial class Form2 : Form
    {
        OleDbConnection con;

        public Form2()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Avtomobillar/Avtomobil.mdb");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        // Form2_Load metodini o'zgartirish
        private void Form2_Load(object sender, EventArgs e)
        {
            display();
            // ComboBoxni 'band' va 'band_emas' bilan to'ldirish
            comboBox1.Items.Add("band");
            comboBox1.Items.Add("band_emas");
            comboBox1.SelectedIndex = 0; // Default 'band' ni tanlash
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellContentClick);
        }

        // display metodini o'zgartirish (Avtomobillar jadvalidagi 'EgasiID'ni 'Bandligi'ga o'zgartirish)
        void display()
        {
            try
            {
                con.Open();
                string query = "SELECT * FROM Avtomobillar";  // Avtomobillar jadvalidagi ma'lumotlar
                OleDbCommand cmd = new OleDbCommand(query, con);
                OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                dataadapter.Fill(dt);
                dataGridView1.DataSource = dt;
                dataadapter.Dispose();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        // Qo'shish metodini o'zgartirish
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // ComboBoxda tanlangan bandlikni olish
                string bandligi = comboBox1.SelectedItem.ToString();

                con.Open();
                string query = "INSERT INTO Avtomobillar ([Modeli], [Ishlab_Chiq_Yili], [Bandligi]) VALUES (@Modeli, @Ishlab_Chiq_Yili, @Bandligi)";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@Modeli", textBox1.Text);  // textBox1 ni ishlatish
                cmd.Parameters.Add("@Ishlab_Chiq_Yili", OleDbType.Date).Value = dateTimePicker1.Value;
                cmd.Parameters.AddWithValue("@Bandligi", bandligi);  // 'Bandligi' ustuniga 'band' yoki 'band_emas' qo'shish
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik yuz berdi: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
            }
        }

        // O'zgartirish metodini o'zgartirish
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("Iltimos, jadvaldan qator tanlang.");
                    return;
                }

                string bandligi = comboBox1.SelectedItem.ToString();
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

                con.Open();
                string query = "UPDATE Avtomobillar SET Modeli=@Modeli, Ishlab_Chiq_Yili=@Ishlab_Chiq_Yili, Bandligi=@Bandligi WHERE AvtoID=@id";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@Modeli", textBox1.Text);
                cmd.Parameters.Add("@Ishlab_Chiq_Yili", OleDbType.Date).Value = dateTimePicker1.Value;
                cmd.Parameters.AddWithValue("@Bandligi", bandligi);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik yuz berdi: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
            }
        }

        // O'chirish metodini o'zgartirish
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("Iltimos, jadvaldan qator tanlang.");
                    return;
                }
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                con.Open();
                string query = "DELETE FROM Avtomobillar WHERE AvtoID=@id";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik yuz berdi: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
            }
        }

        // Tanlaganda chiqarish metodini o'zgartirish
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Modeli"].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(row.Cells["Ishlab_Chiq_Yili"].Value);
                comboBox1.SelectedItem = row.Cells["Bandligi"].Value.ToString();  // 'Bandligi' ustunidan qiymat olish
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
        }


        void display2()
        {
            try
            {
                con.Open();
                string query = "SELECT EgasiID, Familiya_Ism FROM Egalar";
                OleDbCommand cmd = new OleDbCommand(query, con);
                OleDbDataAdapter dataadapter = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                dataadapter.Fill(dt);
                comboBox1.DataSource = dt;
                comboBox1.ValueMember = "EgasiID";
                comboBox1.DisplayMember = "Familiya_Ism";
                dataadapter.Dispose();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}

