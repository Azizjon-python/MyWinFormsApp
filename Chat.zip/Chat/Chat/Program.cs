﻿using Chat;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Chat
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Form1 form1 = new Form1();
            Form2 form2 = new Form2();

            form1.form2 = form2;
            form2.form1 = form1;

            //Hodisaga obuna bo'lish (form1 yuborgan xabar form2 ga keladi)
            form1.MessageSent += form2.MessageReceived;

            form1.Show();
            form2.Show();

            Application.Run(); //Ikkala formni ham ishlashini ta'minlash
        }
    }
}
