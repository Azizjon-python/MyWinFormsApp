﻿using Chat;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chat
{
    public partial class Form1 : Form
    {
        public Form2 form2;
        public event EventHandler<string> MessageSent;

        public Form1()
        {
            InitializeComponent();
        }

        private void sendButton_Click(object sender, EventArgs e)
        {
            string message = messageTextBox.Text;
            OnMessageSent(message); //Hodisani chaqirish
            messageTextBox.Clear();
            chatTextBox.AppendText("Siz: " + message + Environment.NewLine); //Siz yozgan habar
        }

        protected virtual void OnMessageSent(string message) //Hodisani boshqarish
        {
            MessageSent?.Invoke(this, message);
        }

        public void ReceiveMessage(string message) //Form2 dan kelgan habarni qabul qilish
        {
            chatTextBox.AppendText("Do'stingiz: " + message + Environment.NewLine);
        }
    }
}
