﻿using Chat;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chat
{
    public partial class Form2 : Form
    {
        public Form1 form1;
        public Form2()
        {
            InitializeComponent();
        }

        private void sendButton_Click(object sender, EventArgs e)
        {
            string message = messageTextBox.Text;
            form1.ReceiveMessage(message); //Form1 ga xabar yuborish
            messageTextBox.Clear();
            chatTextBox.AppendText("Siz: " + message + Environment.NewLine); //Siz yozgan habar
        }

        public void MessageReceived(object sender, string message) //Form1 dan kelgan habarni qabul qilish
        {
            chatTextBox.AppendText("Do'stingiz: " + message + Environment.NewLine);
        }
    }
}
