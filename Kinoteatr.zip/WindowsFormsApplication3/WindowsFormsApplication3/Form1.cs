﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        OleDbConnection men;
        public Form1()
        {
            InitializeComponent();
            men = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Kinoteatr12.mdb");
        }
        void ochish()
        {
            men.Open();
            String jadval = "SELECT * FROM Kinoteatr";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            men.Close();
        }
        void ochish2()
        {
            men.Open();
            String jadval = "SELECT * FROM Filmlar";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
            adapter.Dispose();
            men.Close();
        }
        void ochish3()
        {
            men.Open();
            String jadval = "SELECT * FROM Mijozlar";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView3.DataSource = dt;
            adapter.Dispose();
            men.Close();
        }        
        void ochish5()
        {
            men.Open();
            String jadval = "SELECT * FROM XodimlaMaoshi";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView5.DataSource = dt;
            adapter.Dispose();
            men.Close();
        }
        void ochish6()
        {
            men.Open();
            string jadval = "SELECT * FROM Xodimlar";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView6.DataSource = dt;
            adapter.Dispose();
            men.Close();
        }
        void filmlar_combobox1()
        {
            men.Open();
            String jadval = "SELECT * FROM Filmlar";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Nomi";
            adapter.Dispose();
            men.Close();
        }
        void mijozlar_combobox6()
        {
            men.Open();
            String jadval = "SELECT * FROM Mijozlar";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox6.DataSource = dt;
            comboBox6.DisplayMember = "IsmFamiliya";
            adapter.Dispose();
            men.Close();
        }
        void xodimlar()
        {
            men.Open();
            string jadval = "SELECT * FROM Xodimlar";
            OleDbCommand cmd = new OleDbCommand(jadval, men);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox2.DataSource = dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName).ToList();
            adapter.Dispose();
            men.Close();
        }
        private void UpdateComboBox5()
        {
            comboBox5.Items.Clear();
            foreach (var kvp in orindiqlar)
            {
                if (kvp.Value == "Bo'sh") // Faqat "Bo'sh" holatdagi o'rindiqlarni qo'shamiz
                {
                    comboBox5.Items.Add(kvp.Key);
                }
            }
        }
        private int returnId(string orindiqRaqami)
        {
            int xonaID = -1;
            men.Open();
            string query = "SELECT ID FROM Orindiq WHERE Orindiq_raqami = @Orindiq_raqami";
            OleDbCommand cmd = new OleDbCommand(query, men);
            cmd.Parameters.AddWithValue("@Orindiq_raqami", orindiqRaqami);
            object result = cmd.ExecuteScalar();
            if (result != null)
            {
                xonaID = Convert.ToInt32(result);
            }
            cmd.Dispose();
            men.Close();
            return xonaID;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ochish();
            ochish2();
            ochish3();         
            ochish5();
            ochish6();
            xodimlar();
            filmlar_combobox1();
            mijozlar_combobox6();
            comboBox4.Items.Add("Luks");
            comboBox4.Items.Add("Standart");
            comboBox4.Items.Add("Econom");
            comboBox7.Items.Add("Band");
            panel2.Visible = true;
            panel1.Visible = true;
            panel3.Visible = true;
            panel4.Visible = true;
            panel5.Visible = true;
            panel6.Visible = false;
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
            dataGridView2.CellClick += new DataGridViewCellEventHandler(dataGridView2_CellClick);
            dataGridView6.CellClick += new DataGridViewCellEventHandler(dataGridView6_CellClick);
            dataGridView5.CellClick += new DataGridViewCellEventHandler(dataGridView5_CellClick);
            dataGridView3.CellClick += new DataGridViewCellEventHandler(dataGridView3_CellClick);
        }
        private void button4_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = tabPage1;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Kinoteatr;
            panel1.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = true;
        }


        //KINOTEATR KINOTEATR KINOTEATR KINOTEATR
        //qo'shish
        private void button6_Click(object sender, EventArgs e)
        {
            men.Open();
            string queryKinoteatr = "INSERT INTO Kinoteatr ([KinoteatrNomi], [KinoteatrJoyi], [Mijoz], [Film_nomi], [Orindiq_turi], [Orindiq_raqami], [Orindiq_holati]) VALUES (@KinoteatrNomi, @KinoteatrJoyi, @Mijoz, @Film_nomi, @Orindiq_turi, @Orindiq_raqami, @Orindiq_holati)";
            OleDbCommand cmdKinoteatr = new OleDbCommand(queryKinoteatr, men);
            cmdKinoteatr.Parameters.AddWithValue("@KinoteatrNomi", textBox2.Text);
            cmdKinoteatr.Parameters.AddWithValue("@KinoteatrJoyi", textBox3.Text);
            cmdKinoteatr.Parameters.AddWithValue("@Mijoz", comboBox6.Text);
            cmdKinoteatr.Parameters.AddWithValue("@Film_nomi", comboBox1.Text);
            string selectedOrindiqTuri = comboBox4.SelectedItem != null ? comboBox4.SelectedItem.ToString() : "";
            cmdKinoteatr.Parameters.AddWithValue("@Orindiq_turi", selectedOrindiqTuri);
            string selectedOrindiqRaqami = comboBox5.SelectedItem != null ? comboBox5.SelectedItem.ToString() : "";
            cmdKinoteatr.Parameters.AddWithValue("@Orindiq_raqami", selectedOrindiqRaqami);
            string selectedOrindiqholati = comboBox7.SelectedItem != null ? comboBox7.SelectedItem.ToString() : "";
            cmdKinoteatr.Parameters.AddWithValue("@Orindiq_holati", selectedOrindiqholati);
            cmdKinoteatr.ExecuteNonQuery();
            int orindiqRaqami;
            if (int.TryParse(selectedOrindiqRaqami, out orindiqRaqami))
            {
                orindiqlar[orindiqRaqami] = "Band";
            }
            UpdateComboBox5();
            cmdKinoteatr.Dispose();
            men.Close();
            ochish();
        }
        //o'zgartirish
        private void button7_Click(object sender, EventArgs e)
        {
            men.Open();
            string selectedOrindiqTuri = comboBox4.SelectedItem != null ? comboBox4.SelectedItem.ToString() : "";
            string selectedOrindiqRaqami = comboBox5.SelectedItem != null ? comboBox5.SelectedItem.ToString() : "";
            string selectedOrindiqholati = comboBox7.SelectedItem != null ? comboBox7.SelectedItem.ToString() : "";
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
            // Oldingi o'rindiq raqamini olish
            string oldOrindiqRaqami = dataGridView1.CurrentRow.Cells["Orindiq_raqami"].Value.ToString();
            // Yangi ma'lumotni yangilash
            string queryKinoteatr = "UPDATE Kinoteatr SET KinoteatrNomi=@KinoteatrNomi, KinoteatrJoyi=@KinoteatrJoyi, Mijoz=@Mijoz, Film_nomi=@Film_nomi, Orindiq_turi=@Orindiq_turi, Orindiq_raqami=@Orindiq_raqami, Orindiq_holati=@Orindiq_holati WHERE Id=@id";
            OleDbCommand cmdKinoteatr = new OleDbCommand(queryKinoteatr, men);
            cmdKinoteatr.Parameters.AddWithValue("@KinoteatrNomi", textBox2.Text);
            cmdKinoteatr.Parameters.AddWithValue("@KinoteatrJoyi", textBox3.Text);
            cmdKinoteatr.Parameters.AddWithValue("@Mijoz", comboBox6.Text);
            cmdKinoteatr.Parameters.AddWithValue("@Film_nomi", comboBox1.Text);
            cmdKinoteatr.Parameters.AddWithValue("@Orindiq_turi", selectedOrindiqTuri);
            cmdKinoteatr.Parameters.AddWithValue("@Orindiq_raqami", selectedOrindiqRaqami);
            cmdKinoteatr.Parameters.AddWithValue("@Orindiq_holati", selectedOrindiqholati);
            cmdKinoteatr.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmdKinoteatr.ExecuteNonQuery();
            int oldRaqam;
            if (int.TryParse(oldOrindiqRaqami, out oldRaqam))
            {
                orindiqlar[oldRaqam] = "Bo'sh";
            }
            // Yangi o'rindiqni "Band" qilish
            int newRaqam;
            if (int.TryParse(selectedOrindiqRaqami, out newRaqam))
            {
                orindiqlar[newRaqam] = "Band";
            }
            cmdKinoteatr.Dispose();
            men.Close();
            ochish();
        }
        //ma'lumot yuklash
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox2.Text = row.Cells["KinoteatrNomi"].Value.ToString();
                textBox3.Text = row.Cells["KinoteatrJoyi"].Value.ToString();
                comboBox6.Text = row.Cells["Mijoz"].Value.ToString();
                comboBox1.Text = row.Cells["Film_nomi"].Value.ToString();
                comboBox4.Text = row.Cells["Orindiq_turi"].Value != null ? row.Cells["Orindiq_turi"].Value.ToString() : "";
                comboBox5.Text = row.Cells["Orindiq_raqami"].Value != null ? row.Cells["Orindiq_raqami"].Value.ToString() : "";
                comboBox7.Text = row.Cells["Orindiq_holati"].Value != null ? row.Cells["Orindiq_holati"].Value.ToString() : "";

            }
        }
        //o'chirish
        private void button8_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
            string oldOrindiqRaqami = dataGridView1.CurrentRow.Cells["Orindiq_raqami"].Value.ToString();
            string Query = "DELETE FROM Kinoteatr WHERE Id=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            // O'chirilgan orindiqni "Bo'sh" qilish
            int oldRaqam;
            if (int.TryParse(oldOrindiqRaqami, out oldRaqam))
            {
                orindiqlar[oldRaqam] = "Bo'sh";
            }
            // comboBox5'ni yangilash
            UpdateComboBox5();
            cmd.Dispose();
            men.Close();
            ochish();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Filmlar;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Mijozlar;
            panel3.Visible = false;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = XodimlarMaoshi;
        }


        //FILMLAR FILMLAR FILMLAR FILMLAR
        //qo'shish
        private void button9_Click(object sender, EventArgs e)
        {
            men.Open();
            string Query = "INSERT INTO Filmlar ([Nomi], [BoshlanishVaqti], [TugashVaqti], [Rejissor]) VALUES (@Nomi, @BoshlanishVaqti, @TugashVaqti, @Rejissor)";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@Nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@BoshlanishVaqti", textBox8.Text);
            cmd.Parameters.AddWithValue("@TugashVaqti", textBox9.Text);
            cmd.Parameters.AddWithValue("@Rejissor", textBox10.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish2();
        }
        //ma'lumot yuklash
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int index = dataGridView2.CurrentRow.Index;
                int id = Convert.ToInt32(dataGridView2.Rows[index].Cells[0].Value);
                textBox1.Text = dataGridView2.Rows[index].Cells[1].Value.ToString();
                textBox8.Text = dataGridView2.Rows[index].Cells[2].Value.ToString();
                textBox9.Text = dataGridView2.Rows[index].Cells[3].Value.ToString();
                textBox10.Text = dataGridView2.Rows[index].Cells[4].Value.ToString();
            }
        }
        //o'zgartirish
        private void button10_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView2.CurrentRow.Cells["Id"].Value);
            string Query = "UPDATE Filmlar SET Nomi=@Nomi, BoshlanishVaqti=@BoshlanishVaqti, TugashVaqti=@TugashVaqti, Rejissor=@Rejissor WHERE Id=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@Nomi", textBox1.Text);
            cmd.Parameters.AddWithValue("@BoshlanishVaqti", textBox8.Text);
            cmd.Parameters.AddWithValue("@TugashVaqti", textBox9.Text);
            cmd.Parameters.AddWithValue("@Rejissor", textBox10.Text);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish2();
        }
        //o'chirish
        private void button11_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
            string Query = "DELETE FROM Filmlar WHERE Id=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish2();
        }


        //MIJOZLAR MIJOZLAR MIJOZLAR MIJOZLAR
        //qo'shish
        private void button12_Click(object sender, EventArgs e)
        {
            
            men.Open();
            string Query = "INSERT INTO Mijozlar ([IsmFamiliya], [TelefonRaqami], [JSHSHR], [Biletraqami], [BiletNarxi]) VALUES (@IsmFamiliya, @TelefonRaqami, @JSHSHR, @Biletraqami, @BiletNarxi)";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@IsmFamiliya", textBox11.Text);
            cmd.Parameters.AddWithValue("@TelefonRaqami", textBox12.Text);
            cmd.Parameters.AddWithValue("@JSHSHR", textBox13.Text);
            cmd.Parameters.AddWithValue("@Biletraqami", textBox14.Text);
            cmd.Parameters.AddWithValue("@BiletNarxi", textBox15.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish3();
        }
        //o'zgartirish
        private void button13_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView3.CurrentRow.Cells["ID"].Value);
            string Query = "UPDATE Mijozlar SET IsmFamiliya=@IsmFamiliya, TelefonRaqami=@TelefonRaqami, JSHSHR=@JSHSHR, Biletraqami=@Biletraqami, BiletNarxi=@BiletNarxi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@IsmFamiliya", textBox11.Text);
            cmd.Parameters.AddWithValue("@TelefonRaqami", textBox12.Text);
            cmd.Parameters.AddWithValue("@JSHSHR", textBox13.Text);
            cmd.Parameters.AddWithValue("@Biletraqami", textBox14.Text);
            cmd.Parameters.AddWithValue("@BiletNarxi", textBox15.Text);
            cmd.Parameters.Add("@ID", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish3();
        }
        //Ko'rsatish
        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int index = dataGridView3.CurrentRow.Index;
                int id = Convert.ToInt32(dataGridView3.Rows[index].Cells[0].Value);
                textBox11.Text = dataGridView3.Rows[index].Cells[1].Value.ToString();
                textBox12.Text = dataGridView3.Rows[index].Cells[2].Value.ToString();
                textBox13.Text = dataGridView3.Rows[index].Cells[3].Value.ToString();
                textBox14.Text = dataGridView3.Rows[index].Cells[4].Value.ToString();
                textBox15.Text = dataGridView3.Rows[index].Cells[5].Value.ToString();
                ochish3();
            }
        }
        //O'chirish
        private void button14_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView3.CurrentRow.Cells["ID"].Value);
            string Query = "DELETE FROM Mijozlar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.Add("@ID", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish3();
        }


        //Xodimlar Xodimlar Xodimlar Xodimlar
        //qo'shish
        private void button16_Click(object sender, EventArgs e)
        {
            
        }
        //o'zgartirish
        private void button17_Click(object sender, EventArgs e)
        {
            
        }
        //Ko'rsatish
        private void dataGridView6_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int index = dataGridView6.CurrentRow.Index;
                int id = Convert.ToInt32(dataGridView6.Rows[index].Cells[0].Value);
                textBox4.Text = dataGridView6.Rows[index].Cells[1].Value.ToString();
                textBox5.Text = dataGridView6.Rows[index].Cells[2].Value.ToString();
                textBox6.Text = dataGridView6.Rows[index].Cells[3].Value.ToString();
                textBox7.Text = dataGridView6.Rows[index].Cells[4].Value.ToString();
                textBox22.Text = dataGridView6.Rows[index].Cells[5].Value.ToString();
            }
        }
        //O'chirish
        private void button18_Click(object sender, EventArgs e)
        {
            
        }


        //Xodimlar Maoshi   Xodimlar Maoshi
        //Qo'shish
        private void button19_Click(object sender, EventArgs e)
        {
            men.Open();
            string Query = "INSERT INTO XodimlaMaoshi ([Lavozim], [Xodim],[Maosh]) VALUES (@Lavozim, @Xodim, @Maosh)";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@Lavozim", comboBox2.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@Xodim", comboBox3.Text);
            cmd.Parameters.AddWithValue("@Maosh", Convert.ToInt32(textBox21.Text));
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish5();
        }
        //O'zgartirish
        private void button20_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView5.CurrentRow.Cells["ID"].Value);
            string Query = "UPDATE XodimlaMaoshi SET Lavozim=Lavozim, Xodim=@Xodim, Maosh=@Maosh WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@Lavozim", comboBox2.Text.ToString());
            cmd.Parameters.AddWithValue("@Xodim", comboBox3.Text);
            cmd.Parameters.AddWithValue("@Maosh", textBox21.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish5();
        }
        //Ko'rsatish
        private void dataGridView5_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int index = dataGridView5.CurrentRow.Index;
                int id = Convert.ToInt32(dataGridView5.Rows[index].Cells[0].Value);
                comboBox2.Text = dataGridView5.Rows[index].Cells[1].Value.ToString();
                comboBox3.Text = dataGridView5.Rows[index].Cells[2].Value.ToString();
                textBox21.Text = dataGridView5.Rows[index].Cells[3].Value.ToString();
            }
        }
        //O'chirish   
        private void button21_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView5.CurrentRow.Cells["ID"].Value);
            string Query = "DELETE FROM XodimlaMaoshi WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish5();
        }


        private void button22_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Mijozlar;
            panel4.Visible = true;
            panel3.Visible = true;
        }        
        private void button23_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Kinoteatr;
            panel5.Visible = false;
            panel3.Visible = true;
        }
        private void button24_Click(object sender, EventArgs e)
        {
            panel2.Visible = !panel2.Visible;
            panel6.Visible = !panel6.Visible;
        }
        private void button26_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Kinoteatr;
        }
        private void button25_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Boshsaxifa;
        }
        private void button27_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Boshsaxifa;
        }
        private void button15_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Boshsaxifa;
        }
        private void button29_Click(object sender, EventArgs e)
        {
            TabControl1.SelectedTab = Boshsaxifa;

        }
        Dictionary<int, string> orindiqlar = new Dictionary<int, string>();
        private void InitializeOrindiqlar()
        {
            if (orindiqlar.Count == 0) // Lug‘atni faqat bir marta to‘ldirish uchun
            {
                for (int i = 1; i <= 100; i++)
                {
                    orindiqlar.Add(i, "Bo'sh");
                }
                for (int i = 101; i <= 200; i++)
                {
                    orindiqlar.Add(i, "Bo'sh");
                }
                for (int i = 201; i <= 300; i++)
                {
                    orindiqlar.Add(i, "Bo'sh");
                }
            }
        }
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            InitializeOrindiqlar(); // Lug‘atni bir marta to‘ldirish uchun tekshirish qo‘shilgan
            comboBox5.Items.Clear();
            int start = 0, end = 0;

            if (comboBox4.SelectedItem != null)
            {
                if (comboBox4.SelectedItem.ToString() == "Luks")
                {
                    start = 1;
                    end = 100;
                }
                else if (comboBox4.SelectedItem.ToString() == "Standart")
                {
                    start = 101;
                    end = 200;
                }
                else if (comboBox4.SelectedItem.ToString() == "Econom")
                {
                    start = 201;
                    end = 300;
                }

                for (int i = start; i <= end; i++)
                {
                    if (orindiqlar.ContainsKey(i) && orindiqlar[i] == "Bo'sh")
                    {
                        comboBox5.Items.Add(i);
                    }
                }
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            men.Open();
            string Query = "INSERT INTO Xodimlar ([Menejer], [Kassir],[Texnik], [Xavfsizlik], [Marketing]) VALUES (@Menejer, @Kassir, @Texnik, @Xavfsizlik, @Marketing)";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@Menejer", textBox4.Text);
            cmd.Parameters.AddWithValue("@Kassir", textBox5.Text);
            cmd.Parameters.AddWithValue("@Texnik", textBox6.Text);
            cmd.Parameters.AddWithValue("@Xavfsizlik", textBox7.Text);
            cmd.Parameters.AddWithValue("@Marketing", textBox22.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Dispose();
            men.Close();
            ochish6();
        }

        private void button32_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView6.CurrentRow.Cells["Id"].Value);
            string Query = "UPDATE Xodimlar SET Menejer=@Menejer, Kassir=@Kassir, Texnik=@Texnik, Xavfsizlik=@Xavfsizlik, Marketing=@Marketing WHERE Id=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.AddWithValue("@Menejer", textBox4.Text);
            cmd.Parameters.AddWithValue("@Kassir", textBox5.Text);
            cmd.Parameters.AddWithValue("@Texnik", textBox6.Text);
            cmd.Parameters.AddWithValue("@Xavfsizlik", textBox7.Text);
            cmd.Parameters.AddWithValue("@Marketing", textBox22.Text);
            cmd.Parameters.Add("@Id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish6();
        }

        private void button31_Click(object sender, EventArgs e)
        {
            men.Open();
            int id = Convert.ToInt32(dataGridView6.CurrentRow.Cells["Id"].Value);
            string Query = "DELETE FROM Xodimlar WHERE Id=@id";
            OleDbCommand cmd = new OleDbCommand(Query, men);
            cmd.Parameters.Add("@Id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            men.Close();
            ochish6();
        }
    }
}
