﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mehmonxona
{
    public partial class Form2 : Form
    {
        OleDbConnection con;
        public Form2()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Mehmonxona1.mdb");
        }
        //Jadvalni ko'rsatish funksiyasi
        void display()
        {
            
            con.Open();
            string query = "Select * from Mehmonlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        //Qidiruv funksiyasi
        void search()
        {
            if (dataGridView1 != null)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = string.Format("Ism Like'%"+txtqidiruv.Text+"%'");
            }
        }
        //Qiymatni ko'rsatadigan funksiya
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Ma'lumotlarni TextBoxlarga yuklaymiz
                txtism.Text = row.Cells["IsmFamiliya"].Value.ToString();
                txttelraqam.Text = row.Cells["Telefon"].Value.ToString();
                txtpasport.Text = row.Cells["Pasport"].Value.ToString();
                txtmanzil.Text = row.Cells["Manzil"].Value.ToString();
                comboBox1.Text = row.Cells["Holati"].Value != null ? row.Cells["Holati"].Value.ToString() : "";

            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("band");
            comboBox1.Items.Add("band_qiluvchi");
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //Orqaga knopka
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        //Yopadigan knopka
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //qo'shish
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "Insert Into Mehmonlar ([IsmFamiliya], [Telefon], [Pasport], [Manzil], [Holati]) VALUES (@IsmFamiliya, @Telefon, @Pasport, @Manzil, @Holati)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@IsmFamiliya", txtism.Text);
            cmd.Parameters.AddWithValue("@Telefon ", txttelraqam.Text);
            cmd.Parameters.AddWithValue("@Pasport", txtpasport.Text);
            cmd.Parameters.AddWithValue("@Manzil", txtmanzil.Text);
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@Holati", selectedItem); cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //O'zgartirish
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "Update Mehmonlar set IsmFamiliya=@IsmFamiliya, Telefon=@Telefon, Pasport=@Pasport, Manzil=@Manzil, Holati=@Holati where ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@IsmFamiliya", txtism.Text);
            cmd.Parameters.AddWithValue("@Telefon ", txttelraqam.Text);
            cmd.Parameters.AddWithValue("@Pasport", txtpasport.Text);
            cmd.Parameters.AddWithValue("@Manzil", txtmanzil.Text);
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@Holati", selectedItem);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //O'chirish
        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "Delete from Mehmonlar where ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //Qidiruv tugmasi
        private void button6_Click(object sender, EventArgs e)
        {
            search();
        }
    }
}

