﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mehmonxona
{
    public partial class Form5 : Form
    {
        OleDbConnection con;
        public Form5()
        {
            InitializeComponent();
            con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\azizj\Desktop\Mehmonxona1.mdb");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        void display()
        {
            try
            {
                con.Open();
                string query = "SELECT * FROM Rezervatsiyalar";
                OleDbCommand cmd = new OleDbCommand(query, con);
                OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                adapter.Dispose();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            XonaTuri.Items.Clear();
            XonaTuri.Items.Add("Standart");
            XonaTuri.Items.Add("Econom");
            XonaTuri.Items.Add("Luks"); ;
            XonaTuri.SelectedIndex = 0;
            XonaTuri.SelectedIndexChanged += XonaTuri_SelectedIndexChanged;
            display();
            display2();
            displayMehmonlar();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        // Ma'lumot qo'shish
        private void button2_Click(object sender, EventArgs e)
        {
            string selectedIsm = Ism.Text; // ComboBox'dan tanlangan ism
            int selectedMehmonID = returnIdForMehmon(selectedIsm); // Tanlangan mehmonning ID'si
            if (selectedMehmonID == -1)
            {
                MessageBox.Show("Tanlangan Mehmon uchun ID topilmadi.");
                return;
            }
            string selectedXonaRaqami = XonaRaqami.SelectedValue.ToString();
            int selectedXonaID = returnId(selectedXonaRaqami);
            if (selectedXonaID == -1)
            {
                MessageBox.Show("Tanlangan Xona raqami uchun XonaID topilmadi.");
                return;
            }
            try
            {
                con.Open();
                string query = "INSERT INTO Rezervatsiyalar ([MehmonID], [XonaTuri], [XonaID], [KelishSanasi], [KetishSanasi]) VALUES (@MehmonID, @XonaTuri, @XonaID, @KelishSanasi, @KetishSanasi)";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@MehmonID", selectedMehmonID);
                string selectedItem = XonaTuri.SelectedItem != null ? XonaTuri.SelectedItem.ToString() : "";
                cmd.Parameters.AddWithValue("@XonaTuri", selectedItem);
                cmd.Parameters.AddWithValue("@XonaID", selectedXonaID);
                cmd.Parameters.Add("@KelishSanasi", OleDbType.Date).Value = dateTimePicker1.Value;
                cmd.Parameters.Add("@KetishSanasi", OleDbType.Date).Value = dateTimePicker2.Value;
                cmd.ExecuteNonQuery();
                string updateQuery = "UPDATE Xonalar SET Holati = 'band' WHERE XonaID = @XonaID";
                OleDbCommand updateCmd = new OleDbCommand(updateQuery, con);
                updateCmd.Parameters.AddWithValue("@XonaID", selectedXonaID);
                updateCmd.ExecuteNonQuery();
                string mehmonQuery = "UPDATE Mehmonlar SET Holati = 'band' WHERE ID=@ID";
                OleDbCommand mehmonCmd = new OleDbCommand(mehmonQuery, con);
                mehmonCmd.Parameters.AddWithValue("@ID", selectedMehmonID);
                mehmonCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
            }
        }
        // Ma'lumot o'chirish
        private void button3_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            int xonaID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["XonaID"].Value);
            int mehmonID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["MehmonID"].Value);
            con.Open();
            string updateQuery = "UPDATE Xonalar SET Holati = 'band_emas' WHERE XonaID = @XonaID";
            OleDbCommand updateCmd = new OleDbCommand(updateQuery, con);
            updateCmd.Parameters.AddWithValue("@XonaID", xonaID);
            updateCmd.ExecuteNonQuery();
            string mehmonQuery = "UPDATE Mehmonlar SET Holati = 'band_qiluvchi' WHERE ID=@ID";
            OleDbCommand mehmonCmd = new OleDbCommand(mehmonQuery, con);
            mehmonCmd.Parameters.AddWithValue("@ID", mehmonID);
            mehmonCmd.ExecuteNonQuery();
            string deleteQuery = "DELETE FROM Rezervatsiyalar WHERE RezervatsiyaID = @id";
            OleDbCommand cmd = new OleDbCommand(deleteQuery, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            con.Close();
            display();
        }
        // Ma'lumot o'zgartirish
        private void button4_Click(object sender, EventArgs e)
        {
            string selectedIsm = Ism.Text; // ComboBox'dan tanlangan ism
            int selectedMehmonID = returnIdForMehmon(selectedIsm); // Tanlangan mehmonning ID'si
            if (selectedMehmonID == -1)
            {
                MessageBox.Show("Tanlangan Mehmon uchun ID topilmadi.");
                return;
            }
            if (XonaRaqami.DataSource == null || XonaRaqami.Items.Count == 0)
            {
                MessageBox.Show("Xona ro'yxati yuklanmagan. Iltimos, qayta urinib ko'ring.");
                return;
            }

            if (XonaRaqami.SelectedValue == null)
            {
                MessageBox.Show("Iltimos, Xona raqamini tanlang.");
                return;
            }

            string selectedXonaRaqami = XonaRaqami.SelectedValue.ToString();
            int selectedXonaID = returnId(selectedXonaRaqami);
            if (selectedXonaID == -1)
            {
                MessageBox.Show("Tanlangan Xona raqami uchun XonaID topilmadi.");
                return;
            }
            try
            {
                if (dataGridView1.CurrentRow != null)
                {
                    int rezervatsiyaID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    int oldXonaID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["XonaID"].Value); // Oldingi XonaID
                    int oldMehmonID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["MehmonID"].Value); // Oldingi MehmonID

                    con.Open();
                    // Rezervatsiyani yangilash
                    string query = "UPDATE Rezervatsiyalar SET MehmonID = @MehmonID, XonaTuri=@XonaTuri, XonaID = @XonaID, KelishSanasi = @KelishSanasi, KetishSanasi = @KetishSanasi WHERE RezervatsiyaID = @id";
                    OleDbCommand cmd = new OleDbCommand(query, con);
                    cmd.Parameters.AddWithValue("@MehmonID", selectedMehmonID);
                    string selectedItem = XonaTuri.SelectedItem != null ? XonaTuri.SelectedItem.ToString() : "";
                    cmd.Parameters.AddWithValue("@XonaTuri", selectedItem);
                    cmd.Parameters.AddWithValue("@XonaID", selectedXonaID);
                    cmd.Parameters.Add("@KelishSanasi", OleDbType.Date).Value = dateTimePicker1.Value;
                    cmd.Parameters.Add("@KetishSanasi", OleDbType.Date).Value = dateTimePicker2.Value;
                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = rezervatsiyaID;
                    cmd.ExecuteNonQuery();
                    // Oldingi xonaning holatini 'band_emas' qilish
                    if (oldXonaID != selectedXonaID)
                    {
                        string updateOldXonaQuery = "UPDATE Xonalar SET Holati = 'band_emas' WHERE XonaID = @XonaID";
                        OleDbCommand updateOldCmd = new OleDbCommand(updateOldXonaQuery, con);
                        updateOldCmd.Parameters.AddWithValue("@XonaID", oldXonaID);
                        updateOldCmd.ExecuteNonQuery();
                    }
                    // Yangi xonaning holatini 'band' qilish
                    string updateNewXonaQuery = "UPDATE Xonalar SET Holati = 'band' WHERE XonaID = @XonaID";
                    OleDbCommand updateNewCmd = new OleDbCommand(updateNewXonaQuery, con);
                    updateNewCmd.Parameters.AddWithValue("@XonaID", selectedXonaID);
                    updateNewCmd.ExecuteNonQuery();
                    // Oldingi mehmonning holatini 'band_qiluvchi' qilish
                    if (oldXonaID != selectedXonaID)
                    {
                        string updateOldMehmonQuery = "UPDATE Mehmonlar SET Holati = 'band_qiluvchi' WHERE ID = @ID";
                        OleDbCommand updateOldmehmonCmd = new OleDbCommand(updateOldMehmonQuery, con);
                        updateOldmehmonCmd.Parameters.AddWithValue("@ID", oldMehmonID);
                        updateOldmehmonCmd.ExecuteNonQuery();
                    }
                    //Yangi xonaning holatini 'band' qilish
                    string updateNewMehmonQuery = "UPDATE Xonalar SET Holati = 'band' WHERE ID = @ID";
                    OleDbCommand updateNewMehmonCmd = new OleDbCommand(updateNewMehmonQuery, con);
                    updateNewMehmonCmd.Parameters.AddWithValue("@ID", selectedMehmonID);
                    updateNewMehmonCmd.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Yangilash uchun biror qatorni tanlang!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
                display(); // Jadvalni yangilash
            }
        }
        //tanlash
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Tanlangan satr mavjudligini tekshiramiz
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // XonaTuri'ni to'ldirish
                XonaTuri.Text = row.Cells["XonaTuri"].Value != null && row.Cells["XonaTuri"].Value != DBNull.Value
                    ? row.Cells["XonaTuri"].Value.ToString()
                    : "";
                dateTimePicker1.Value = row.Cells["KelishSanasi"].Value != null && row.Cells["KelishSanasi"].Value != DBNull.Value ? Convert.ToDateTime(row.Cells["KelishSanasi"].Value) : dateTimePicker1.Value;
                dateTimePicker2.Value = row.Cells["KetishSanasi"].Value != null && row.Cells["KetishSanasi"].Value != DBNull.Value ? Convert.ToDateTime(row.Cells["KetishSanasi"].Value) : dateTimePicker2.Value;

                int xonaID = row.Cells["XonaID"].Value != null && row.Cells["XonaID"].Value != DBNull.Value ? Convert.ToInt32(row.Cells["XonaID"].Value) : -1; 
                string xonaRaqami = GetXonaRaqamiByID(xonaID);
                XonaRaqami.Text = xonaRaqami;
                int mehmonID = row.Cells["MehmonID"].Value != null && row.Cells["MehmonID"].Value != DBNull.Value
            ? Convert.ToInt32(row.Cells["MehmonID"].Value)
            : -1;
                Ism.Text = mehmonID != -1 ? GetMehmonIsmiByID(mehmonID) : "";
            }
        }
        //id larni bog'lash uchun 3ta funksiya
        void display2()
        {
            try
            {
                con.Open();
                // XonaTuri va Holati = 'band_emas' bo'lgan xonalarni tanlash
                string query = "SELECT * FROM Xonalar WHERE XonaTuri = ? AND Holati = 'band_emas'";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("?", XonaTuri.SelectedItem.ToString());
                OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                XonaRaqami.DataSource = dt;
                XonaRaqami.ValueMember = "XonaRaqami";  // XonaRaqami ustuni
                XonaRaqami.DisplayMember = "XonaRaqami"; // XonaRaqami combo boxda ko'rsatiladigan ma'lumot
                adapter.Dispose();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void XonaTuri_SelectedIndexChanged(object sender, EventArgs e)
        {
            display2();
        }
        private int returnId(string xonaRaqami)
        {
            int xonaID = -1;
            con.Open();
            string query = "SELECT XonaID FROM Xonalar WHERE XonaRaqami = @XonaRaqami";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@XonaRaqami", xonaRaqami);
            object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
            if (result != null)
            {
                // Agar XonaID topilsa, uni int turida qaytaramiz
                xonaID = Convert.ToInt32(result);
            }
            cmd.Dispose();
            con.Close();
            return xonaID;
        }
        private string GetXonaRaqamiByID(int xonaID)
        {
            string xonaRaqami = null;
            con.Open();
            string query = "SELECT XonaRaqami FROM Xonalar WHERE XonaID = @XonaID";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@XonaID", xonaID);
            object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
            if (result != null)
            {
                // Agar XonaRaqami topilsa, uni qaytaramiz
                xonaRaqami = result.ToString();
            }
            cmd.Dispose();
            con.Close();
            return xonaRaqami;
        }
        //id larni bog'lash uchun keyingi 3ta funksiya
        void displayMehmonlar()
        {
            con.Open();
            string query = "SELECT IsmFamiliya FROM Mehmonlar WHERE Holati = 'band_qiluvchi'";
            OleDbCommand cmd = new OleDbCommand(query, con);            
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            Ism.DataSource = dt;
            Ism.ValueMember = "IsmFamiliya";
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private int returnIdForMehmon(string selectedIsm)
        {
            int mehmonID = -1;
            con.Open();
            string query = "SELECT ID FROM Mehmonlar WHERE IsmFamiliya = @IsmFamiliya";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@IsmFamiliya", selectedIsm);
            object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
            if (result != null)
            {
                mehmonID = Convert.ToInt32(result);
            }
            cmd.Dispose();
            con.Close();
            return mehmonID;
        }
        private string GetMehmonIsmiByID(int ID)
        {
            string ism = null;
            string query = "SELECT IsmFamiliya FROM Mehmonlar WHERE ID = @ID";
            try
            {
                con.Open();
                using (OleDbCommand cmd = new OleDbCommand(query, con))
                {
                    cmd.Parameters.Add("@ID", OleDbType.Integer).Value = ID; // Parametr qo'shish
                    object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
                    if (result != null && result != DBNull.Value)
                    {
                        ism = result.ToString();
                    }
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Ma'lumot bazasi bilan bog'liq xatolik: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return ism;
        }
    }
}
