﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Mehmonxona
{
    public partial class Form6 : Form
    {
        OleDbConnection con;

        public Form6()
        {
            InitializeComponent();
            con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\azizj\Desktop\Mehmonxona1.mdb");
        }

        // Form yuklanganda ma'lumotlarni ko'rsatish
        private void Form6_Load(object sender, EventArgs e)
        {
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }

        // Ma'lumotlarni chiqarish funksiyasi
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Xodimlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }

        // Qatorni tanlanganda textboxlarga ma'lumot yuklash
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Direktor"].Value.ToString();
                textBox2.Text = row.Cells["IshYurutuvchi"].Value.ToString();
                textBox3.Text = row.Cells["HujjatRasmiylashtiruvchi"].Value.ToString();
                textBox4.Text = row.Cells["Kassir"].Value.ToString();
                textBox5.Text = row.Cells["Xizmatchi"].Value.ToString();
                textBox6.Text = row.Cells["Qorovul"].Value.ToString();
            }
        }

        // Form1 ga qaytish
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        // Ma'lumot qo'shish
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "INSERT INTO Xodimlar ([Direktor], [IshYurutuvchi], [HujjatRasmiylashtiruvchi], [Kassir], [Xizmatchi], [Qorovul]) " +
                               "VALUES (@Direktor, @IshYurutuvchi, @HujjatRasmiylashtiruvchi, @Kassir, @Xizmatchi, @Qorovul)";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@Direktor", textBox1.Text);
                cmd.Parameters.AddWithValue("@IshYurutuvchi", textBox2.Text);
                cmd.Parameters.AddWithValue("@HujjatRasmiylashtiruvchi", textBox3.Text);
                cmd.Parameters.AddWithValue("@Kassir", textBox4.Text);
                cmd.Parameters.AddWithValue("@Xizmatchi", textBox5.Text);
                cmd.Parameters.AddWithValue("@Qorovul", textBox6.Text);
                cmd.ExecuteNonQuery();
                //MessageBox.Show("Ma'lumot muvaffaqiyatli qo'shildi!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
            }
        }

        // Ma'lumotni o'zgartirish
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow != null)
                {
                    int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value);
                    con.Open();
                    string query = "UPDATE Xodimlar SET Direktor = @Direktor, IshYurutuvchi = @IshYurutuvchi, " +
                                   "HujjatRasmiylashtiruvchi = @HujjatRasmiylashtiruvchi, Kassir = @Kassir, " +
                                   "Xizmatchi = @Xizmatchi, Qorovul = @Qorovul WHERE ID = @ID";
                    OleDbCommand cmd = new OleDbCommand(query, con);
                    cmd.Parameters.AddWithValue("@Direktor", textBox1.Text);
                    cmd.Parameters.AddWithValue("@IshYurutuvchi", textBox2.Text);
                    cmd.Parameters.AddWithValue("@HujjatRasmiylashtiruvchi", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Kassir", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Xizmatchi", textBox5.Text);
                    cmd.Parameters.AddWithValue("@Qorovul", textBox6.Text);
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.ExecuteNonQuery();
                    //MessageBox.Show("Ma'lumot muvaffaqiyatli yangilandi!");
                }
                else
                {
                    MessageBox.Show("O'zgartirish uchun biror qatorni tanlang!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
            }
        }

        // Ma'lumot o'chirish
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow != null)
                {
                    int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value);
                    con.Open();
                    string query = "DELETE FROM Xodimlar WHERE ID = @ID";
                    OleDbCommand cmd = new OleDbCommand(query, con);
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.ExecuteNonQuery();
                    //MessageBox.Show("Ma'lumot muvaffaqiyatli o'chirildi!");
                }
                else
                {
                    MessageBox.Show("O'chirish uchun biror qatorni tanlang!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xatolik: " + ex.Message);
            }
            finally
            {
                con.Close();
                display();
            }
        }
    }
}
