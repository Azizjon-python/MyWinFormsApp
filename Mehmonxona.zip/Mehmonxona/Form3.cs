﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Mehmonxona
{
    public partial class Form3 : Form
    {
        OleDbConnection com;
        public Form3()
        {
            InitializeComponent();
            com = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Mehmonxona1.mdb");
        }
        void display()
        {
            com.Open();
            string query = "Select * from Xonalar";
            OleDbCommand cmd = new OleDbCommand(query, com);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            com.Close();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Tanlangan satr mavjudligini tekshiramiz
            if (e.RowIndex >= 0)
            {
                // Tanlangan satrni olamiz
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // TextBoxlarga ma'lumotlarni yuklash
                textBox1.Text = row.Cells["XonaRaqami"].Value != null ? row.Cells["XonaRaqami"].Value.ToString() : "";
                textBox2.Text = row.Cells["Narxi"].Value != null ? row.Cells["Narxi"].Value.ToString() : "";

                // ComboBoxlarga qiymatlarni yuklash
                comboBox1.Text = row.Cells["XonaTuri"].Value != null ? row.Cells["XonaTuri"].Value.ToString() : "";
                comboBox2.Text = row.Cells["Holati"].Value != null ? row.Cells["Holati"].Value.ToString() : "";
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void Form3_Load(object sender, EventArgs e)
        {
            // ComboBoxni faqat bir marta to'ldiramiz
            comboBox1.Items.Add("Standart");
            comboBox1.Items.Add("Econom");
            comboBox1.Items.Add("Luks");
            comboBox2.Items.Add("Band");
            comboBox2.Items.Add("Band_emas");
            display(); // Jadvalni yuklash
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);

        }
        //Qo'shish
        private void button2_Click(object sender, EventArgs e)
        {
            com.Open();
            string query = "Insert Into Xonalar ([XonaRaqami], [XonaTuri], [Narxi], [Holati]) VALUES (@XonaRaqami, @XonaTuri, @Narxi, @Holati)";
            OleDbCommand cmd = new OleDbCommand(query, com);
            cmd.Parameters.AddWithValue("@XonaRaqami", textBox1.Text);
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@XonaTuri", selectedItem);
            cmd.Parameters.AddWithValue("@Narxi", textBox2.Text); 
            string selectedItem1 = comboBox2.SelectedItem != null ? comboBox2.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@Holati", selectedItem1);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            com.Close();
            display();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //O'zgartirish
        private void button3_Click(object sender, EventArgs e)
        {
            com.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "Update Xonalar set XonaRaqami=@XonaRaqami, XonaTuri=@XonaTuri, Narxi=@Narxi, Holati=@Holati where XonaID=@id";
            OleDbCommand cmd = new OleDbCommand(query, com);
            cmd.Parameters.AddWithValue("@XonaRaqami", textBox1.Text);
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@XonaTuri", selectedItem);
            cmd.Parameters.AddWithValue("@Narxi", textBox2.Text);
            string selectedItem1 = comboBox2.SelectedItem != null ? comboBox2.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@Holati", selectedItem1);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            com.Close();
            display();
        }
        //O'chirish
        private void button4_Click(object sender, EventArgs e)
        {
            com.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "Delete From Xonalar where XonaID=@id";
            OleDbCommand cmd = new OleDbCommand(query, com);
            cmd.Parameters.Add("@XonaID", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            com.Close();
            display();
        }
    }
}
