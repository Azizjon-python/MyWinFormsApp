﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Mehmonxona
{
    public partial class Form4 : Form
    {
        OleDbConnection con;
        public Form4()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Mehmonxona1.mdb");
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Tolovlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Naqt");
            comboBox1.Items.Add("Plastik karta");
            display();
            display2();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        private void label5_Click(object sender, EventArgs e)
        {

        }
        //orqaga
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        //Qo'shish
        private void button1_Click(object sender, EventArgs e)
        {
            string selectedXonaRaqami = XonaRaqami.SelectedValue.ToString();
            int selectedXonaID = returnId(selectedXonaRaqami);

            if (selectedXonaID == -1)
            {
                MessageBox.Show("Tanlangan Xona raqami uchun XonaID topilmadi.");
                return;
            }

            con.Open();
            string query = "INSERT INTO Tolovlar ([TolanganSumma], [TolovSanasi], [TolovTuri], [XonaID]) VALUES (@TolanganSumma, @TolovSanasi, @TolovTuri, @XonaID)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@TolanganSumma", textBox1.Text);
            cmd.Parameters.Add("@TolovSanasi", OleDbType.DBDate).Value = dateTimePicker1.Value;
            //cmd.Parameters.AddWithValue("@TolovTuri", textBox3.Text);
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@To'lov turi", selectedItem);
            cmd.Parameters.AddWithValue("@XonaID", selectedXonaID);  // XonaID ni ComboBox tanlovidan olish
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();  // Jadvalni yangilash
        }
        //O'zgartirish
        private void button2_Click(object sender, EventArgs e)
        {
            // ComboBox-dan tanlangan XonaID qiymatini olish
            string selectedXonaRaqami = XonaRaqami.SelectedValue.ToString();
            int selectedXonaID = returnId(selectedXonaRaqami);

            if (selectedXonaID == -1)
            {
                MessageBox.Show("Tanlangan Xona raqami uchun XonaID topilmadi.");
                return;
            }

            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            // Ma'lumotlarni yangilash
            string query = "UPDATE Tolovlar SET TolanganSumma=@TolanganSumma, TolovSanasi=@TolovSanasi, TolovTuri=@TolovTuri, XonaID=@XonaID WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@TolanganSumma", textBox1.Text);
            cmd.Parameters.Add("@TolovSanasi", OleDbType.DBDate).Value = dateTimePicker1.Value;
            string selectedItem = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "";
            cmd.Parameters.AddWithValue("@TolovTuri", selectedItem);
            cmd.Parameters.AddWithValue("@XonaID", selectedXonaID);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();  // Jadvalni yangilash
        }
        //O'chirish
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Tolovlar WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //tanlash
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Tanlangan satr mavjudligini tekshiramiz
            if (e.RowIndex >= 0)
            {
                int index = dataGridView1.CurrentRow.Index;
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["TolanganSumma"].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[index].Cells[3].Value);
                comboBox1.Text = row.Cells["TolovTuri"].Value != null ? row.Cells["TolovTuri"].Value.ToString() : "";
                // XonaID ni olish
                int xonaID = Convert.ToInt32(row.Cells["XonaID"].Value);
                // XonaID ga asoslangan XonaRaqami ni olish
                string xonaRaqami = GetXonaRaqamiByID(xonaID);
                // ComboBox ga XonaRaqami ni o'rnatish
                XonaRaqami.Text = xonaRaqami;
            }
        }
        void display2()
        {
            con.Open();
            string query = "SELECT * FROM Xonalar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            XonaRaqami.DataSource = dt;
            XonaRaqami.ValueMember = "XonaRaqami";  // ComboBox'ga XonaRaqami-ni o'zgartir
            XonaRaqami.DisplayMember = "XonaRaqami"; // ComboBox'da ko'rsatiladigan ma'lumot
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        private int returnId(string xonaRaqami)
        {
            int xonaID = -1;
            con.Open();
            string query = "SELECT XonaID FROM Xonalar WHERE XonaRaqami = @XonaRaqami";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@XonaRaqami", xonaRaqami);
            object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
            if (result != null)
            {
                // Agar XonaID topilsa, uni int turida qaytaramiz
                xonaID = Convert.ToInt32(result);
            }
            cmd.Dispose();
            con.Close();
            return xonaID;
        }
        private string GetXonaRaqamiByID(int xonaID)
        {
            string xonaRaqami = null;
            con.Open();
            string query = "SELECT XonaRaqami FROM Xonalar WHERE XonaID = @XonaID";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@XonaID", xonaID);
            object result = cmd.ExecuteScalar(); // Yagona qiymatni olish
            if (result != null)
            {
                // Agar XonaRaqami topilsa, uni qaytaramiz
                xonaRaqami = result.ToString();
            }
            cmd.Dispose();
            con.Close();
            return xonaRaqami;
        }
    }
}
