﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Mehmonxona
{
    public partial class Form7 : Form
    {
        OleDbConnection con;
        public Form7()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/Mehmonxona1.mdb");

        }
        void display1()
        {
            con.Open();
            string jadval = "SELECT * FROM Xodimlar";
            OleDbCommand cmd = new OleDbCommand(jadval, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            // Ustun nomlarini ComboBox1 ga yuklash
            comboBox1.DataSource = dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName).ToList();
            adapter.Dispose();
            con.Close();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tanlanganUstun = comboBox1.SelectedItem.ToString();
            //con.Open();
            // SQL so'rovni tanlangan ustun bilan yaratish
            string query = "SELECT [" + tanlanganUstun + "] FROM Xodimlar";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            // comboBox3 ga qiymatlarni yuklash
            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = tanlanganUstun;
            adapter.Dispose();
            con.Close();
        }
        private void Form7_Load(object sender, EventArgs e)
        {
            display1();
            display();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM Oylik_maosh";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            adapter.Dispose();
            cmd.Dispose();
            con.Close();
        }
        //Qo'shish
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO Oylik_maosh ([Lavozim], [Xodim], [Maosh]) VALUES (@Lavozim, @Xodim, @Maosh)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Lavozim", comboBox1.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@Xodim", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Maosh", textBox1.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //O'zgartirish
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            string query = "UPDATE Oylik_maosh SET Lavozim=@Lavozim, Xodim=@Xodim, Maosh=@Maosh WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Lavozim", comboBox1.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@Xodim", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Maosh", textBox1.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        //O'chirish
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM Oylik_maosh WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.Add("@id", OleDbType.Integer).Value = id;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Maosh"].Value != null ? row.Cells["Maosh"].Value.ToString() : "";
                comboBox1.Text = row.Cells["Lavozim"].Value != null ? row.Cells["Lavozim"].Value.ToString() : "";
                comboBox2.Text = row.Cells["Xodim"].Value != null ? row.Cells["Xodim"].Value.ToString() : "";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}
