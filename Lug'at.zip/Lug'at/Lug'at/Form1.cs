﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Lug_at
{
    public partial class Form1 : Form
    {
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:/Users/azizj/Desktop/dictionary.mdb");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            display();
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = true;
        }
        void display()
        {
            con.Open();
            string query = "SELECT * FROM dictionary1";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView2.DataSource = dt;
            con.Close();
        }
        void search()
        {
            string searchTerm = textBox1.Text.Trim();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                string query = "SELECT * FROM dictionary1 WHERE Uzbek LIKE '%" + searchTerm + "%'";
                OleDbCommand cmd = new OleDbCommand(query, con);
                OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                con.Open();
                adapter.Fill(dt);
                con.Close();
                dataGridView1.DataSource = dt;
            }
            else
            {
                display();
            }
        }
        void search1()
        {
            string searchTerm = textBox6.Text.Trim();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                string query = "SELECT * FROM dictionary1 WHERE English LIKE '%" + searchTerm + "%'";
                OleDbCommand cmd = new OleDbCommand(query, con);
                OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                con.Open();
                adapter.Fill(dt);
                con.Close();
                dataGridView2.DataSource = dt;
            }
            else
            {
                display();
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            search();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = !panel2.Visible;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Add();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Edit();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Remove();
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            search1();
        }
        void Add()
        {
            con.Open();
            string query = "INSERT INTO dictionary1 (Uzbek, English) VALUES (@Uzbek, @English)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Uzbek", textBox2.Text);
            cmd.Parameters.AddWithValue("@English", textBox3.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        void Edit()
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE dictionary1 SET Uzbek=@Uzbek, English=@English WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Uzbek", textBox2.Text);
            cmd.Parameters.AddWithValue("@English", textBox3.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        void Remove()
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM dictionary1 WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Visible = !panel1.Visible;
                  
        }
        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "INSERT INTO dictionary1 (Uzbek, English) VALUES (@Uzbek, @English)";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Uzbek", textBox5.Text);
            cmd.Parameters.AddWithValue("@English", textBox4.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "UPDATE dictionary1 SET Uzbek=@Uzbek, English=@English WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Uzbek", textBox5.Text);
            cmd.Parameters.AddWithValue("@English", textBox4.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            int index = dataGridView1.CurrentRow.Index;
            int id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
            string query = "DELETE FROM dictionary1 WHERE ID=@id";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            display();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            panel3.Visible = !panel3.Visible;
        }
        private void button10_Click(object sender, EventArgs e)
        {
            panel2.Visible = !panel2.Visible;
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            search1();
        }
       
    }
}
